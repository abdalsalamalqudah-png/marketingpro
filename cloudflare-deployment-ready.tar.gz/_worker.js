var vt=Object.defineProperty;var He=e=>{throw TypeError(e)};var yt=(e,t,s)=>t in e?vt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:s}):e[t]=s;var u=(e,t,s)=>yt(e,typeof t!="symbol"?t+"":t,s),Te=(e,t,s)=>t.has(e)||He("Cannot "+s);var r=(e,t,s)=>(Te(e,t,"read from private field"),s?s.call(e):t.get(e)),f=(e,t,s)=>t.has(e)?He("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,s),p=(e,t,s,a)=>(Te(e,t,"write to private field"),a?a.call(e,s):t.set(e,s),s),m=(e,t,s)=>(Te(e,t,"access private method"),s);var Fe=(e,t,s,a)=>({set _(i){p(e,t,i,s)},get _(){return r(e,t,a)}});var Be=(e,t,s)=>(a,i)=>{let l=-1;return d(0);async function d(o){if(o<=l)throw new Error("next() called multiple times");l=o;let n,c=!1,x;if(e[o]?(x=e[o][0][0],a.req.routeIndex=o):x=o===e.length&&i||void 0,x)try{n=await x(a,()=>d(o+1))}catch(g){if(g instanceof Error&&t)a.error=g,n=await t(g,a),c=!0;else throw g}else a.finalized===!1&&s&&(n=await s(a));return n&&(a.finalized===!1||c)&&(a.res=n),a}},wt=Symbol(),jt=async(e,t=Object.create(null))=>{const{all:s=!1,dot:a=!1}=t,l=(e instanceof at?e.raw.headers:e.headers).get("Content-Type");return l!=null&&l.startsWith("multipart/form-data")||l!=null&&l.startsWith("application/x-www-form-urlencoded")?kt(e,{all:s,dot:a}):{}};async function kt(e,t){const s=await e.formData();return s?Et(s,t):{}}function Et(e,t){const s=Object.create(null);return e.forEach((a,i)=>{t.all||i.endsWith("[]")?Pt(s,i,a):s[i]=a}),t.dot&&Object.entries(s).forEach(([a,i])=>{a.includes(".")&&(St(s,a,i),delete s[a])}),s}var Pt=(e,t,s)=>{e[t]!==void 0?Array.isArray(e[t])?e[t].push(s):e[t]=[e[t],s]:t.endsWith("[]")?e[t]=[s]:e[t]=s},St=(e,t,s)=>{let a=e;const i=t.split(".");i.forEach((l,d)=>{d===i.length-1?a[l]=s:((!a[l]||typeof a[l]!="object"||Array.isArray(a[l])||a[l]instanceof File)&&(a[l]=Object.create(null)),a=a[l])})},Je=e=>{const t=e.split("/");return t[0]===""&&t.shift(),t},Ct=e=>{const{groups:t,path:s}=$t(e),a=Je(s);return Rt(a,t)},$t=e=>{const t=[];return e=e.replace(/\{[^}]+\}/g,(s,a)=>{const i=`@${a}`;return t.push([i,s]),i}),{groups:t,path:e}},Rt=(e,t)=>{for(let s=t.length-1;s>=0;s--){const[a]=t[s];for(let i=e.length-1;i>=0;i--)if(e[i].includes(a)){e[i]=e[i].replace(a,t[s][1]);break}}return e},je={},Tt=(e,t)=>{if(e==="*")return"*";const s=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(s){const a=`${e}#${t}`;return je[a]||(s[2]?je[a]=t&&t[0]!==":"&&t[0]!=="*"?[a,s[1],new RegExp(`^${s[2]}(?=/${t})`)]:[e,s[1],new RegExp(`^${s[2]}$`)]:je[a]=[e,s[1],!0]),je[a]}return null},De=(e,t)=>{try{return t(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,s=>{try{return t(s)}catch{return s}})}},Ot=e=>De(e,decodeURI),Ze=e=>{const t=e.url,s=t.indexOf("/",t.indexOf(":")+4);let a=s;for(;a<t.length;a++){const i=t.charCodeAt(a);if(i===37){const l=t.indexOf("?",a),d=t.slice(s,l===-1?void 0:l);return Ot(d.includes("%25")?d.replace(/%25/g,"%2525"):d)}else if(i===63)break}return t.slice(s,a)},At=e=>{const t=Ze(e);return t.length>1&&t.at(-1)==="/"?t.slice(0,-1):t},se=(e,t,...s)=>(s.length&&(t=se(t,...s)),`${(e==null?void 0:e[0])==="/"?"":"/"}${e}${t==="/"?"":`${(e==null?void 0:e.at(-1))==="/"?"":"/"}${(t==null?void 0:t[0])==="/"?t.slice(1):t}`}`),et=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const t=e.split("/"),s=[];let a="";return t.forEach(i=>{if(i!==""&&!/\:/.test(i))a+="/"+i;else if(/\:/.test(i))if(/\?/.test(i)){s.length===0&&a===""?s.push("/"):s.push(a);const l=i.replace("?","");a+="/"+l,s.push(a)}else a+="/"+i}),s.filter((i,l,d)=>d.indexOf(i)===l)},Oe=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?De(e,st):e):e,tt=(e,t,s)=>{let a;if(!s&&t&&!/[%+]/.test(t)){let d=e.indexOf(`?${t}`,8);for(d===-1&&(d=e.indexOf(`&${t}`,8));d!==-1;){const o=e.charCodeAt(d+t.length+1);if(o===61){const n=d+t.length+2,c=e.indexOf("&",n);return Oe(e.slice(n,c===-1?void 0:c))}else if(o==38||isNaN(o))return"";d=e.indexOf(`&${t}`,d+1)}if(a=/[%+]/.test(e),!a)return}const i={};a??(a=/[%+]/.test(e));let l=e.indexOf("?",8);for(;l!==-1;){const d=e.indexOf("&",l+1);let o=e.indexOf("=",l);o>d&&d!==-1&&(o=-1);let n=e.slice(l+1,o===-1?d===-1?void 0:d:o);if(a&&(n=Oe(n)),l=d,n==="")continue;let c;o===-1?c="":(c=e.slice(o+1,d===-1?void 0:d),a&&(c=Oe(c))),s?(i[n]&&Array.isArray(i[n])||(i[n]=[]),i[n].push(c)):i[n]??(i[n]=c)}return t?i[t]:i},It=tt,Mt=(e,t)=>tt(e,t,!0),st=decodeURIComponent,Ne=e=>De(e,st),re,$,B,it,rt,Ie,_,ze,at=(ze=class{constructor(e,t="/",s=[[]]){f(this,B);u(this,"raw");f(this,re);f(this,$);u(this,"routeIndex",0);u(this,"path");u(this,"bodyCache",{});f(this,_,e=>{const{bodyCache:t,raw:s}=this,a=t[e];if(a)return a;const i=Object.keys(t)[0];return i?t[i].then(l=>(i==="json"&&(l=JSON.stringify(l)),new Response(l)[e]())):t[e]=s[e]()});this.raw=e,this.path=t,p(this,$,s),p(this,re,{})}param(e){return e?m(this,B,it).call(this,e):m(this,B,rt).call(this)}query(e){return It(this.url,e)}queries(e){return Mt(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const t={};return this.raw.headers.forEach((s,a)=>{t[a]=s}),t}async parseBody(e){var t;return(t=this.bodyCache).parsedBody??(t.parsedBody=await jt(this,e))}json(){return r(this,_).call(this,"text").then(e=>JSON.parse(e))}text(){return r(this,_).call(this,"text")}arrayBuffer(){return r(this,_).call(this,"arrayBuffer")}blob(){return r(this,_).call(this,"blob")}formData(){return r(this,_).call(this,"formData")}addValidatedData(e,t){r(this,re)[e]=t}valid(e){return r(this,re)[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[wt](){return r(this,$)}get matchedRoutes(){return r(this,$)[0].map(([[,e]])=>e)}get routePath(){return r(this,$)[0].map(([[,e]])=>e)[this.routeIndex].path}},re=new WeakMap,$=new WeakMap,B=new WeakSet,it=function(e){const t=r(this,$)[0][this.routeIndex][1][e],s=m(this,B,Ie).call(this,t);return s?/\%/.test(s)?Ne(s):s:void 0},rt=function(){const e={},t=Object.keys(r(this,$)[0][this.routeIndex][1]);for(const s of t){const a=m(this,B,Ie).call(this,r(this,$)[0][this.routeIndex][1][s]);a&&typeof a=="string"&&(e[s]=/\%/.test(a)?Ne(a):a)}return e},Ie=function(e){return r(this,$)[1]?r(this,$)[1][e]:e},_=new WeakMap,ze),Dt={Stringify:1},lt=async(e,t,s,a,i)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const l=e.callbacks;return l!=null&&l.length?(i?i[0]+=e:i=[e],Promise.all(l.map(o=>o({phase:t,buffer:i,context:a}))).then(o=>Promise.all(o.filter(Boolean).map(n=>lt(n,t,!1,a,i))).then(()=>i[0]))):Promise.resolve(e)},Lt="text/plain; charset=UTF-8",Ae=(e,t)=>({"Content-Type":e,...t}),me,be,D,le,L,E,he,ne,de,Y,ve,ye,U,ae,qe,Ht=(qe=class{constructor(e,t){f(this,U);f(this,me);f(this,be);u(this,"env",{});f(this,D);u(this,"finalized",!1);u(this,"error");f(this,le);f(this,L);f(this,E);f(this,he);f(this,ne);f(this,de);f(this,Y);f(this,ve);f(this,ye);u(this,"render",(...e)=>(r(this,ne)??p(this,ne,t=>this.html(t)),r(this,ne).call(this,...e)));u(this,"setLayout",e=>p(this,he,e));u(this,"getLayout",()=>r(this,he));u(this,"setRenderer",e=>{p(this,ne,e)});u(this,"header",(e,t,s)=>{this.finalized&&p(this,E,new Response(r(this,E).body,r(this,E)));const a=r(this,E)?r(this,E).headers:r(this,Y)??p(this,Y,new Headers);t===void 0?a.delete(e):s!=null&&s.append?a.append(e,t):a.set(e,t)});u(this,"status",e=>{p(this,le,e)});u(this,"set",(e,t)=>{r(this,D)??p(this,D,new Map),r(this,D).set(e,t)});u(this,"get",e=>r(this,D)?r(this,D).get(e):void 0);u(this,"newResponse",(...e)=>m(this,U,ae).call(this,...e));u(this,"body",(e,t,s)=>m(this,U,ae).call(this,e,t,s));u(this,"text",(e,t,s)=>!r(this,Y)&&!r(this,le)&&!t&&!s&&!this.finalized?new Response(e):m(this,U,ae).call(this,e,t,Ae(Lt,s)));u(this,"json",(e,t,s)=>m(this,U,ae).call(this,JSON.stringify(e),t,Ae("application/json",s)));u(this,"html",(e,t,s)=>{const a=i=>m(this,U,ae).call(this,i,t,Ae("text/html; charset=UTF-8",s));return typeof e=="object"?lt(e,Dt.Stringify,!1,{}).then(a):a(e)});u(this,"redirect",(e,t)=>{const s=String(e);return this.header("Location",/[^\x00-\xFF]/.test(s)?encodeURI(s):s),this.newResponse(null,t??302)});u(this,"notFound",()=>(r(this,de)??p(this,de,()=>new Response),r(this,de).call(this,this)));p(this,me,e),t&&(p(this,L,t.executionCtx),this.env=t.env,p(this,de,t.notFoundHandler),p(this,ye,t.path),p(this,ve,t.matchResult))}get req(){return r(this,be)??p(this,be,new at(r(this,me),r(this,ye),r(this,ve))),r(this,be)}get event(){if(r(this,L)&&"respondWith"in r(this,L))return r(this,L);throw Error("This context has no FetchEvent")}get executionCtx(){if(r(this,L))return r(this,L);throw Error("This context has no ExecutionContext")}get res(){return r(this,E)||p(this,E,new Response(null,{headers:r(this,Y)??p(this,Y,new Headers)}))}set res(e){if(r(this,E)&&e){e=new Response(e.body,e);for(const[t,s]of r(this,E).headers.entries())if(t!=="content-type")if(t==="set-cookie"){const a=r(this,E).headers.getSetCookie();e.headers.delete("set-cookie");for(const i of a)e.headers.append("set-cookie",i)}else e.headers.set(t,s)}p(this,E,e),this.finalized=!0}get var(){return r(this,D)?Object.fromEntries(r(this,D)):{}}},me=new WeakMap,be=new WeakMap,D=new WeakMap,le=new WeakMap,L=new WeakMap,E=new WeakMap,he=new WeakMap,ne=new WeakMap,de=new WeakMap,Y=new WeakMap,ve=new WeakMap,ye=new WeakMap,U=new WeakSet,ae=function(e,t,s){const a=r(this,E)?new Headers(r(this,E).headers):r(this,Y)??new Headers;if(typeof t=="object"&&"headers"in t){const l=t.headers instanceof Headers?t.headers:new Headers(t.headers);for(const[d,o]of l)d.toLowerCase()==="set-cookie"?a.append(d,o):a.set(d,o)}if(s)for(const[l,d]of Object.entries(s))if(typeof d=="string")a.set(l,d);else{a.delete(l);for(const o of d)a.append(l,o)}const i=typeof t=="number"?t:(t==null?void 0:t.status)??r(this,le);return new Response(e,{status:i,headers:a})},qe),y="ALL",Ft="all",Bt=["get","post","put","delete","options","patch"],nt="Can not add a route since the matcher is already built.",dt=class extends Error{},Nt="__COMPOSED_HANDLER",_t=e=>e.text("404 Not Found",404),_e=(e,t)=>{if("getResponse"in e){const s=e.getResponse();return t.newResponse(s.body,s)}return console.error(e),t.text("Internal Server Error",500)},R,w,ct,T,V,ke,Ee,Ge,ot=(Ge=class{constructor(t={}){f(this,w);u(this,"get");u(this,"post");u(this,"put");u(this,"delete");u(this,"options");u(this,"patch");u(this,"all");u(this,"on");u(this,"use");u(this,"router");u(this,"getPath");u(this,"_basePath","/");f(this,R,"/");u(this,"routes",[]);f(this,T,_t);u(this,"errorHandler",_e);u(this,"onError",t=>(this.errorHandler=t,this));u(this,"notFound",t=>(p(this,T,t),this));u(this,"fetch",(t,...s)=>m(this,w,Ee).call(this,t,s[1],s[0],t.method));u(this,"request",(t,s,a,i)=>t instanceof Request?this.fetch(s?new Request(t,s):t,a,i):(t=t.toString(),this.fetch(new Request(/^https?:\/\//.test(t)?t:`http://localhost${se("/",t)}`,s),a,i)));u(this,"fire",()=>{addEventListener("fetch",t=>{t.respondWith(m(this,w,Ee).call(this,t.request,t,void 0,t.request.method))})});[...Bt,Ft].forEach(l=>{this[l]=(d,...o)=>(typeof d=="string"?p(this,R,d):m(this,w,V).call(this,l,r(this,R),d),o.forEach(n=>{m(this,w,V).call(this,l,r(this,R),n)}),this)}),this.on=(l,d,...o)=>{for(const n of[d].flat()){p(this,R,n);for(const c of[l].flat())o.map(x=>{m(this,w,V).call(this,c.toUpperCase(),r(this,R),x)})}return this},this.use=(l,...d)=>(typeof l=="string"?p(this,R,l):(p(this,R,"*"),d.unshift(l)),d.forEach(o=>{m(this,w,V).call(this,y,r(this,R),o)}),this);const{strict:a,...i}=t;Object.assign(this,i),this.getPath=a??!0?t.getPath??Ze:At}route(t,s){const a=this.basePath(t);return s.routes.map(i=>{var d;let l;s.errorHandler===_e?l=i.handler:(l=async(o,n)=>(await Be([],s.errorHandler)(o,()=>i.handler(o,n))).res,l[Nt]=i.handler),m(d=a,w,V).call(d,i.method,i.path,l)}),this}basePath(t){const s=m(this,w,ct).call(this);return s._basePath=se(this._basePath,t),s}mount(t,s,a){let i,l;a&&(typeof a=="function"?l=a:(l=a.optionHandler,a.replaceRequest===!1?i=n=>n:i=a.replaceRequest));const d=l?n=>{const c=l(n);return Array.isArray(c)?c:[c]}:n=>{let c;try{c=n.executionCtx}catch{}return[n.env,c]};i||(i=(()=>{const n=se(this._basePath,t),c=n==="/"?0:n.length;return x=>{const g=new URL(x.url);return g.pathname=g.pathname.slice(c)||"/",new Request(g,x)}})());const o=async(n,c)=>{const x=await s(i(n.req.raw),...d(n));if(x)return x;await c()};return m(this,w,V).call(this,y,se(t,"*"),o),this}},R=new WeakMap,w=new WeakSet,ct=function(){const t=new ot({router:this.router,getPath:this.getPath});return t.errorHandler=this.errorHandler,p(t,T,r(this,T)),t.routes=this.routes,t},T=new WeakMap,V=function(t,s,a){t=t.toUpperCase(),s=se(this._basePath,s);const i={basePath:this._basePath,path:s,method:t,handler:a};this.router.add(t,s,[a,i]),this.routes.push(i)},ke=function(t,s){if(t instanceof Error)return this.errorHandler(t,s);throw t},Ee=function(t,s,a,i){if(i==="HEAD")return(async()=>new Response(null,await m(this,w,Ee).call(this,t,s,a,"GET")))();const l=this.getPath(t,{env:a}),d=this.router.match(i,l),o=new Ht(t,{path:l,matchResult:d,env:a,executionCtx:s,notFoundHandler:r(this,T)});if(d[0].length===1){let c;try{c=d[0][0][0][0](o,async()=>{o.res=await r(this,T).call(this,o)})}catch(x){return m(this,w,ke).call(this,x,o)}return c instanceof Promise?c.then(x=>x||(o.finalized?o.res:r(this,T).call(this,o))).catch(x=>m(this,w,ke).call(this,x,o)):c??r(this,T).call(this,o)}const n=Be(d[0],this.errorHandler,r(this,T));return(async()=>{try{const c=await n(o);if(!c.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return c.res}catch(c){return m(this,w,ke).call(this,c,o)}})()},Ge),Se="[^/]+",ge=".*",fe="(?:|/.*)",ie=Symbol(),Ut=new Set(".\\+*[^]$()");function zt(e,t){return e.length===1?t.length===1?e<t?-1:1:-1:t.length===1||e===ge||e===fe?1:t===ge||t===fe?-1:e===Se?1:t===Se?-1:e.length===t.length?e<t?-1:1:t.length-e.length}var X,Q,O,We,Me=(We=class{constructor(){f(this,X);f(this,Q);f(this,O,Object.create(null))}insert(t,s,a,i,l){if(t.length===0){if(r(this,X)!==void 0)throw ie;if(l)return;p(this,X,s);return}const[d,...o]=t,n=d==="*"?o.length===0?["","",ge]:["","",Se]:d==="/*"?["","",fe]:d.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let c;if(n){const x=n[1];let g=n[2]||Se;if(x&&n[2]&&(g===".*"||(g=g.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(g))))throw ie;if(c=r(this,O)[g],!c){if(Object.keys(r(this,O)).some(b=>b!==ge&&b!==fe))throw ie;if(l)return;c=r(this,O)[g]=new Me,x!==""&&p(c,Q,i.varIndex++)}!l&&x!==""&&a.push([x,r(c,Q)])}else if(c=r(this,O)[d],!c){if(Object.keys(r(this,O)).some(x=>x.length>1&&x!==ge&&x!==fe))throw ie;if(l)return;c=r(this,O)[d]=new Me}c.insert(o,s,a,i,l)}buildRegExpStr(){const s=Object.keys(r(this,O)).sort(zt).map(a=>{const i=r(this,O)[a];return(typeof r(i,Q)=="number"?`(${a})@${r(i,Q)}`:Ut.has(a)?`\\${a}`:a)+i.buildRegExpStr()});return typeof r(this,X)=="number"&&s.unshift(`#${r(this,X)}`),s.length===0?"":s.length===1?s[0]:"(?:"+s.join("|")+")"}},X=new WeakMap,Q=new WeakMap,O=new WeakMap,We),Ce,we,Ve,qt=(Ve=class{constructor(){f(this,Ce,{varIndex:0});f(this,we,new Me)}insert(e,t,s){const a=[],i=[];for(let d=0;;){let o=!1;if(e=e.replace(/\{[^}]+\}/g,n=>{const c=`@\\${d}`;return i[d]=[c,n],d++,o=!0,c}),!o)break}const l=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let d=i.length-1;d>=0;d--){const[o]=i[d];for(let n=l.length-1;n>=0;n--)if(l[n].indexOf(o)!==-1){l[n]=l[n].replace(o,i[d][1]);break}}return r(this,we).insert(l,t,a,r(this,Ce),s),a}buildRegExp(){let e=r(this,we).buildRegExpStr();if(e==="")return[/^$/,[],[]];let t=0;const s=[],a=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(i,l,d)=>l!==void 0?(s[++t]=Number(l),"$()"):(d!==void 0&&(a[Number(d)]=++t),"")),[new RegExp(`^${e}`),s,a]}},Ce=new WeakMap,we=new WeakMap,Ve),xt=[],Gt=[/^$/,[],Object.create(null)],Pe=Object.create(null);function pt(e){return Pe[e]??(Pe[e]=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(t,s)=>s?`\\${s}`:"(?:|/.*)")}$`))}function Wt(){Pe=Object.create(null)}function Vt(e){var c;const t=new qt,s=[];if(e.length===0)return Gt;const a=e.map(x=>[!/\*|\/:/.test(x[0]),...x]).sort(([x,g],[b,S])=>x?1:b?-1:g.length-S.length),i=Object.create(null);for(let x=0,g=-1,b=a.length;x<b;x++){const[S,A,v]=a[x];S?i[A]=[v.map(([C])=>[C,Object.create(null)]),xt]:g++;let P;try{P=t.insert(A,g,S)}catch(C){throw C===ie?new dt(A):C}S||(s[g]=v.map(([C,ee])=>{const xe=Object.create(null);for(ee-=1;ee>=0;ee--){const[I,$e]=P[ee];xe[I]=$e}return[C,xe]}))}const[l,d,o]=t.buildRegExp();for(let x=0,g=s.length;x<g;x++)for(let b=0,S=s[x].length;b<S;b++){const A=(c=s[x][b])==null?void 0:c[1];if(!A)continue;const v=Object.keys(A);for(let P=0,C=v.length;P<C;P++)A[v[P]]=o[A[v[P]]]}const n=[];for(const x in d)n[x]=s[d[x]];return[l,n,i]}function te(e,t){if(e){for(const s of Object.keys(e).sort((a,i)=>i.length-a.length))if(pt(s).test(t))return[...e[s]]}}var z,q,ce,ut,gt,Ke,Kt=(Ke=class{constructor(){f(this,ce);u(this,"name","RegExpRouter");f(this,z);f(this,q);p(this,z,{[y]:Object.create(null)}),p(this,q,{[y]:Object.create(null)})}add(e,t,s){var o;const a=r(this,z),i=r(this,q);if(!a||!i)throw new Error(nt);a[e]||[a,i].forEach(n=>{n[e]=Object.create(null),Object.keys(n[y]).forEach(c=>{n[e][c]=[...n[y][c]]})}),t==="/*"&&(t="*");const l=(t.match(/\/:/g)||[]).length;if(/\*$/.test(t)){const n=pt(t);e===y?Object.keys(a).forEach(c=>{var x;(x=a[c])[t]||(x[t]=te(a[c],t)||te(a[y],t)||[])}):(o=a[e])[t]||(o[t]=te(a[e],t)||te(a[y],t)||[]),Object.keys(a).forEach(c=>{(e===y||e===c)&&Object.keys(a[c]).forEach(x=>{n.test(x)&&a[c][x].push([s,l])})}),Object.keys(i).forEach(c=>{(e===y||e===c)&&Object.keys(i[c]).forEach(x=>n.test(x)&&i[c][x].push([s,l]))});return}const d=et(t)||[t];for(let n=0,c=d.length;n<c;n++){const x=d[n];Object.keys(i).forEach(g=>{var b;(e===y||e===g)&&((b=i[g])[x]||(b[x]=[...te(a[g],x)||te(a[y],x)||[]]),i[g][x].push([s,l-c+n+1]))})}}match(e,t){Wt();const s=m(this,ce,ut).call(this);return this.match=(a,i)=>{const l=s[a]||s[y],d=l[2][i];if(d)return d;const o=i.match(l[0]);if(!o)return[[],xt];const n=o.indexOf("",1);return[l[1][n],o]},this.match(e,t)}},z=new WeakMap,q=new WeakMap,ce=new WeakSet,ut=function(){const e=Object.create(null);return Object.keys(r(this,q)).concat(Object.keys(r(this,z))).forEach(t=>{e[t]||(e[t]=m(this,ce,gt).call(this,t))}),p(this,z,p(this,q,void 0)),e},gt=function(e){const t=[];let s=e===y;return[r(this,z),r(this,q)].forEach(a=>{const i=a[e]?Object.keys(a[e]).map(l=>[l,a[e][l]]):[];i.length!==0?(s||(s=!0),t.push(...i)):e!==y&&t.push(...Object.keys(a[y]).map(l=>[l,a[y][l]]))}),s?Vt(t):null},Ke),G,H,Ye,Yt=(Ye=class{constructor(e){u(this,"name","SmartRouter");f(this,G,[]);f(this,H,[]);p(this,G,e.routers)}add(e,t,s){if(!r(this,H))throw new Error(nt);r(this,H).push([e,t,s])}match(e,t){if(!r(this,H))throw new Error("Fatal error");const s=r(this,G),a=r(this,H),i=s.length;let l=0,d;for(;l<i;l++){const o=s[l];try{for(let n=0,c=a.length;n<c;n++)o.add(...a[n]);d=o.match(e,t)}catch(n){if(n instanceof dt)continue;throw n}this.match=o.match.bind(o),p(this,G,[o]),p(this,H,void 0);break}if(l===i)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,d}get activeRouter(){if(r(this,H)||r(this,G).length!==1)throw new Error("No active router has been determined yet.");return r(this,G)[0]}},G=new WeakMap,H=new WeakMap,Ye),ue=Object.create(null),W,k,J,oe,j,F,K,Xe,ft=(Xe=class{constructor(e,t,s){f(this,F);f(this,W);f(this,k);f(this,J);f(this,oe,0);f(this,j,ue);if(p(this,k,s||Object.create(null)),p(this,W,[]),e&&t){const a=Object.create(null);a[e]={handler:t,possibleKeys:[],score:0},p(this,W,[a])}p(this,J,[])}insert(e,t,s){p(this,oe,++Fe(this,oe)._);let a=this;const i=Ct(t),l=[];for(let d=0,o=i.length;d<o;d++){const n=i[d],c=i[d+1],x=Tt(n,c),g=Array.isArray(x)?x[0]:n;if(g in r(a,k)){a=r(a,k)[g],x&&l.push(x[1]);continue}r(a,k)[g]=new ft,x&&(r(a,J).push(x),l.push(x[1])),a=r(a,k)[g]}return r(a,W).push({[e]:{handler:s,possibleKeys:l.filter((d,o,n)=>n.indexOf(d)===o),score:r(this,oe)}}),a}search(e,t){var o;const s=[];p(this,j,ue);let i=[this];const l=Je(t),d=[];for(let n=0,c=l.length;n<c;n++){const x=l[n],g=n===c-1,b=[];for(let S=0,A=i.length;S<A;S++){const v=i[S],P=r(v,k)[x];P&&(p(P,j,r(v,j)),g?(r(P,k)["*"]&&s.push(...m(this,F,K).call(this,r(P,k)["*"],e,r(v,j))),s.push(...m(this,F,K).call(this,P,e,r(v,j)))):b.push(P));for(let C=0,ee=r(v,J).length;C<ee;C++){const xe=r(v,J)[C],I=r(v,j)===ue?{}:{...r(v,j)};if(xe==="*"){const N=r(v,k)["*"];N&&(s.push(...m(this,F,K).call(this,N,e,r(v,j))),p(N,j,I),b.push(N));continue}const[$e,Le,pe]=xe;if(!x&&!(pe instanceof RegExp))continue;const M=r(v,k)[$e],ht=l.slice(n).join("/");if(pe instanceof RegExp){const N=pe.exec(ht);if(N){if(I[Le]=N[0],s.push(...m(this,F,K).call(this,M,e,r(v,j),I)),Object.keys(r(M,k)).length){p(M,j,I);const Re=((o=N[0].match(/\//))==null?void 0:o.length)??0;(d[Re]||(d[Re]=[])).push(M)}continue}}(pe===!0||pe.test(x))&&(I[Le]=x,g?(s.push(...m(this,F,K).call(this,M,e,I,r(v,j))),r(M,k)["*"]&&s.push(...m(this,F,K).call(this,r(M,k)["*"],e,I,r(v,j)))):(p(M,j,I),b.push(M)))}}i=b.concat(d.shift()??[])}return s.length>1&&s.sort((n,c)=>n.score-c.score),[s.map(({handler:n,params:c})=>[n,c])]}},W=new WeakMap,k=new WeakMap,J=new WeakMap,oe=new WeakMap,j=new WeakMap,F=new WeakSet,K=function(e,t,s,a){const i=[];for(let l=0,d=r(e,W).length;l<d;l++){const o=r(e,W)[l],n=o[t]||o[y],c={};if(n!==void 0&&(n.params=Object.create(null),i.push(n),s!==ue||a&&a!==ue))for(let x=0,g=n.possibleKeys.length;x<g;x++){const b=n.possibleKeys[x],S=c[n.score];n.params[b]=a!=null&&a[b]&&!S?a[b]:s[b]??(a==null?void 0:a[b]),c[n.score]=!0}}return i},Xe),Z,Qe,Xt=(Qe=class{constructor(){u(this,"name","TrieRouter");f(this,Z);p(this,Z,new ft)}add(e,t,s){const a=et(t);if(a){for(let i=0,l=a.length;i<l;i++)r(this,Z).insert(e,a[i],s);return}r(this,Z).insert(e,t,s)}match(e,t){return r(this,Z).search(e,t)}},Z=new WeakMap,Qe),mt=class extends ot{constructor(e={}){super(e),this.router=e.router??new Yt({routers:[new Kt,new Xt]})}};const h=new mt;h.get("/",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>🚀 Marketing Pro - منصة التسويق الاحترافية</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { 
                font-family: 'Cairo', sans-serif; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
            }
            .card-hover { 
                transition: all 0.3s ease; 
                backdrop-filter: blur(10px);
            }
            .card-hover:hover { 
                transform: translateY(-5px); 
                box-shadow: 0 20px 40px rgba(0,0,0,0.2); 
            }
            .animate-pulse-slow { animation: pulse 3s infinite; }
            .success-animation {
                animation: successBounce 0.6s ease-out;
            }
            @keyframes successBounce {
                0% { transform: scale(0.8); opacity: 0; }
                50% { transform: scale(1.1); }
                100% { transform: scale(1); opacity: 1; }
            }
        </style>
    </head>
    <body>
        <!-- Header العلوي -->
        <header class="text-white py-6">
            <nav class="container mx-auto px-6">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4 space-x-reverse">
                        <div class="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-lg">
                            <i class="fas fa-rocket text-blue-600 text-2xl animate-pulse-slow"></i>
                        </div>
                        <div>
                            <h1 class="text-3xl font-black">Marketing Pro</h1>
                            <p class="text-blue-200 text-sm">منصة التسويق الشاملة</p>
                        </div>
                    </div>
                    <div class="hidden md:flex space-x-6 space-x-reverse">
                        <a href="#features" class="hover:text-yellow-300 transition font-semibold">الميزات</a>
                        <a href="/login" class="hover:text-yellow-300 transition font-semibold">تسجيل الدخول</a>
                        <a href="/demo" class="hover:text-yellow-300 transition font-semibold">العرض التوضيحي</a>
                    </div>
                </div>
            </nav>
        </header>

        <!-- الرسالة الواضحة للمستخدم -->
        <section class="py-20">
            <div class="container mx-auto px-6 text-center">
                <div class="bg-white/10 backdrop-blur-lg rounded-3xl p-12 max-w-4xl mx-auto border border-white/20">
                    <div class="success-animation">
                        <div class="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                            <i class="fas fa-check-circle text-white text-4xl"></i>
                        </div>
                        
                        <h1 class="text-5xl font-black text-white mb-6 leading-tight">
                            🎉 التحديث الجديد جاهز!
                        </h1>
                        
                        <div class="bg-green-500/20 border border-green-400/50 rounded-2xl p-6 mb-8">
                            <h2 class="text-2xl font-bold text-green-100 mb-4">✅ تم تطبيق جميع التحسينات بنجاح</h2>
                            <ul class="text-right text-green-200 space-y-2 text-lg">
                                <li><i class="fas fa-rocket ml-3"></i>واجهة جديدة احترافية بالكامل</li>
                                <li><i class="fas fa-database ml-3"></i>قواعد بيانات حقيقية 100%</li>
                                <li><i class="fas fa-users ml-3"></i>نظام إدارة العملاء المتطور</li>
                                <li><i class="fas fa-envelope ml-3"></i>نظام البريد الإلكتروني المتكامل</li>
                                <li><i class="fas fa-whatsapp ml-3"></i>ربط واتساب بزنس</li>
                                <li><i class="fas fa-chart-line ml-3"></i>تحليلات متقدمة ولوحات تحكم ذكية</li>
                            </ul>
                        </div>

                        <!-- أزرار الإجراء -->
                        <div class="grid md:grid-cols-3 gap-6 mt-12">
                            <a href="/dashboard" class="card-hover bg-gradient-to-br from-blue-600 to-blue-700 text-white p-6 rounded-2xl font-bold text-xl shadow-2xl block">
                                <i class="fas fa-tachometer-alt text-3xl mb-3 block"></i>
                                لوحة التحكم الرئيسية
                                <div class="text-blue-200 text-sm mt-2">ادخل للنظام الكامل</div>
                            </a>
                            
                            <a href="/login" class="card-hover bg-gradient-to-br from-green-600 to-green-700 text-white p-6 rounded-2xl font-bold text-xl shadow-2xl block">
                                <i class="fas fa-sign-in-alt text-3xl mb-3 block"></i>
                                تسجيل الدخول
                                <div class="text-green-200 text-sm mt-2">للمستخدمين المسجلين</div>
                            </a>
                            
                            <a href="/demo" class="card-hover bg-gradient-to-br from-purple-600 to-purple-700 text-white p-6 rounded-2xl font-bold text-xl shadow-2xl block">
                                <i class="fas fa-play-circle text-3xl mb-3 block"></i>
                                العرض التوضيحي
                                <div class="text-purple-200 text-sm mt-2">شاهد الميزات الجديدة</div>
                            </a>
                        </div>
                        
                        <!-- إحصائيات سريعة -->
                        <div class="grid md:grid-cols-4 gap-4 mt-12 text-center">
                            <div class="bg-white/10 rounded-xl p-4">
                                <div class="text-3xl font-black text-white">100%</div>
                                <div class="text-blue-200 text-sm">قواعد بيانات حقيقية</div>
                            </div>
                            <div class="bg-white/10 rounded-xl p-4">
                                <div class="text-3xl font-black text-white">15+</div>
                                <div class="text-blue-200 text-sm">أدوات تسويق متطورة</div>
                            </div>
                            <div class="bg-white/10 rounded-xl p-4">
                                <div class="text-3xl font-black text-white">24/7</div>
                                <div class="text-blue-200 text-sm">دعم فني متواصل</div>
                            </div>
                            <div class="bg-white/10 rounded-xl p-4">
                                <div class="text-3xl font-black text-white">🚀</div>
                                <div class="text-blue-200 text-sm">أداء فائق السرعة</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- معلومات إضافية -->
        <section class="pb-20">
            <div class="container mx-auto px-6">
                <div class="bg-white/5 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
                    <div class="text-center text-white">
                        <h2 class="text-2xl font-bold mb-4">
                            <i class="fas fa-sparkles text-yellow-300 ml-2"></i>
                            تم الانتهاء من جميع التطويرات المطلوبة
                        </h2>
                        <p class="text-blue-200 text-lg max-w-3xl mx-auto">
                            تم تطوير النظام بالكامل ليصبح منصة تسويق احترافية حقيقية مع قواعد بيانات فعلية وميزات متقدمة. 
                            الآن يمكنك إدارة عملائك وحملاتك التسويقية بكفاءة عالية.
                        </p>
                        
                        <div class="mt-6 text-yellow-300 font-semibold">
                            <i class="fas fa-clock ml-2"></i>
                            آخر تحديث: ${new Date().toLocaleString("ar-SA")}
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <script>
            // تأثير بصري للزر
            document.querySelectorAll('.card-hover').forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-10px) scale(1.02)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });
            
            // رسالة تأكيد
            setTimeout(() => {
                console.log('🚀 Marketing Pro تم تحميله بنجاح!');
            }, 1000);
        <\/script>
    </body>
    </html>
  `));h.get("/login",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>تسجيل الدخول - Marketing Pro</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { 
                font-family: 'Cairo', sans-serif; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
            }
        </style>
    </head>
    <body class="flex items-center justify-center p-4">
        <div class="bg-white/10 backdrop-blur-lg rounded-3xl p-8 w-full max-w-md border border-white/20">
            <div class="text-center mb-8">
                <div class="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl">
                    <i class="fas fa-rocket text-blue-600 text-3xl"></i>
                </div>
                <h1 class="text-3xl font-black text-white mb-2">تسجيل الدخول</h1>
                <p class="text-blue-200">ادخل إلى لوحة التحكم الخاصة بك</p>
            </div>

            <div class="space-y-6">
                <div>
                    <label class="block text-white font-semibold mb-2">
                        <i class="fas fa-envelope ml-2"></i>البريد الإلكتروني
                    </label>
                    <input type="email" class="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-yellow-400" 
                           placeholder="أدخل بريدك الإلكتروني" value="admin@marketingpro.com">
                </div>
                
                <div>
                    <label class="block text-white font-semibold mb-2">
                        <i class="fas fa-lock ml-2"></i>كلمة المرور
                    </label>
                    <input type="password" class="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-yellow-400" 
                           placeholder="أدخل كلمة المرور" value="123456">
                </div>
                
                <button onclick="login()" class="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl font-bold text-lg hover:from-green-600 hover:to-green-700 transition shadow-xl">
                    <i class="fas fa-sign-in-alt ml-2"></i>
                    دخول للنظام
                </button>
                
                <div class="text-center">
                    <a href="/" class="text-yellow-300 hover:text-yellow-200 transition">
                        <i class="fas fa-arrow-right ml-2"></i>العودة للصفحة الرئيسية
                    </a>
                </div>
            </div>
            
            <!-- بيانات تجريبية -->
            <div class="mt-8 bg-blue-500/20 border border-blue-400/50 rounded-xl p-4">
                <h4 class="text-white font-bold mb-2">
                    <i class="fas fa-info-circle ml-2"></i>بيانات الدخول التجريبية
                </h4>
                <div class="text-blue-200 text-sm space-y-1">
                    <p><strong>البريد:</strong> admin@marketingpro.com</p>
                    <p><strong>كلمة المرور:</strong> 123456</p>
                </div>
            </div>
        </div>

        <script>
            function login() {
                // محاكاة تسجيل دخول ناجح
                alert('🎉 تم تسجيل الدخول بنجاح!\\n\\nسيتم توجيهك إلى لوحة التحكم...');
                setTimeout(() => {
                    window.location.href = '/dashboard';
                }, 1500);
            }
        <\/script>
    </body>
    </html>
  `));h.get("/dashboard",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>لوحة التحكم - Marketing Pro</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { font-family: 'Cairo', sans-serif; }
            .sidebar-item { transition: all 0.3s ease; }
            .sidebar-item:hover { background-color: #3B82F6; color: white; }
            .sidebar-item.active { background-color: #2563EB; color: white; }
            .content-area { transition: margin-right 0.3s ease; }
            @media (max-width: 768px) {
                .sidebar { transform: translateX(100%); }
                .sidebar.open { transform: translateX(0); }
                .content-area { margin-right: 0 !important; }
            }
        </style>
    </head>
    <body class="bg-gray-100 h-screen overflow-hidden">
        <!-- الهيدر العلوي -->
        <header class="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6 fixed top-0 right-0 left-0 z-30">
            <div class="flex items-center space-x-4 space-x-reverse">
                <button id="sidebarToggle" class="md:hidden text-gray-600 hover:text-blue-600">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div class="flex items-center space-x-3 space-x-reverse">
                    <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-rocket text-white text-sm"></i>
                    </div>
                    <h1 class="text-lg font-bold text-gray-800">Marketing Pro</h1>
                </div>
            </div>
            
            <div class="flex items-center space-x-4 space-x-reverse">
                <div class="flex items-center space-x-2 space-x-reverse text-sm text-gray-600">
                    <i class="fas fa-user-circle text-lg"></i>
                    <span>أحمد محمد</span>
                </div>
                <button onclick="handleLogout()" class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition text-sm">
                    <i class="fas fa-sign-out-alt ml-1"></i>خروج
                </button>
            </div>
        </header>

        <!-- القائمة الجانبية -->
        <aside id="sidebar" class="sidebar fixed right-0 top-16 h-full bg-white shadow-lg border-l w-64 z-20 overflow-y-auto">
            <div class="p-4">
                <!-- قسم الرئيسية -->
                <div class="mb-6">
                    <h3 class="text-xs font-semibold text-gray-400 uppercase mb-2 px-3">الرئيسية</h3>
                    <ul class="space-y-1">
                        <li>
                            <a href="/dashboard" class="sidebar-item active flex items-center px-3 py-2 rounded-lg text-sm">
                                <i class="fas fa-tachometer-alt ml-3 w-5"></i>
                                لوحة التحكم
                            </a>
                        </li>
                        <li>
                            <a href="/analytics" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-chart-line ml-3 w-5"></i>
                                التحليلات والإحصائيات
                            </a>
                        </li>
                        <li>
                            <a href="/reports" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-file-chart-pie ml-3 w-5"></i>
                                التقارير المفصلة
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- قسم إدارة العملاء -->
                <div class="mb-6">
                    <h3 class="text-xs font-semibold text-gray-400 uppercase mb-2 px-3">إدارة العملاء</h3>
                    <ul class="space-y-1">
                        <li>
                            <a href="/customers" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-users ml-3 w-5"></i>
                                قائمة العملاء
                            </a>
                        </li>
                        <li>
                            <a href="/segments" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-layer-group ml-3 w-5"></i>
                                تقسيم العملاء
                            </a>
                        </li>
                        <li>
                            <a href="/leads" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-user-plus ml-3 w-5"></i>
                                العملاء المحتملين
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- قسم الحملات التسويقية -->
                <div class="mb-6">
                    <h3 class="text-xs font-semibold text-gray-400 uppercase mb-2 px-3">الحملات التسويقية</h3>
                    <ul class="space-y-1">
                        <li>
                            <a href="/marketing-strategy" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-brain ml-3 w-5"></i>
                                استراتيجية التسويق بالذكاء الاصطناعي
                            </a>
                        </li>
                        <li>
                            <a href="/email-campaigns" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-envelope ml-3 w-5"></i>
                                حملات البريد الإلكتروني
                            </a>
                        </li>
                        <li>
                            <a href="/whatsapp" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fab fa-whatsapp ml-3 w-5"></i>
                                واتساب بزنس
                            </a>
                        </li>
                        <li>
                            <a href="/social-media" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-share-alt ml-3 w-5"></i>
                                وسائل التواصل الاجتماعي
                            </a>
                        </li>
                        <li>
                            <a href="/sms-campaigns" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-sms ml-3 w-5"></i>
                                حملات الرسائل النصية
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- قسم الأدوات -->
                <div class="mb-6">
                    <h3 class="text-xs font-semibold text-gray-400 uppercase mb-2 px-3">الأدوات المتقدمة</h3>
                    <ul class="space-y-1">
                        <li>
                            <a href="/automation" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-robot ml-3 w-5"></i>
                                الأتمتة الذكية
                            </a>
                        </li>
                        <li>
                            <a href="/templates" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-file-alt ml-3 w-5"></i>
                                قوالب الرسائل
                            </a>
                        </li>
                        <li>
                            <a href="/integrations" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-plug ml-3 w-5"></i>
                                التكامل مع التطبيقات
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- قسم الإعدادات -->
                <div class="mb-6">
                    <h3 class="text-xs font-semibold text-gray-400 uppercase mb-2 px-3">الإعدادات</h3>
                    <ul class="space-y-1">
                        <li>
                            <a href="/profile" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-user-cog ml-3 w-5"></i>
                                الملف الشخصي
                            </a>
                        </li>
                        <li>
                            <a href="/team" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-users-cog ml-3 w-5"></i>
                                إدارة الفريق
                            </a>
                        </li>
                        <li>
                            <a href="/billing" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-credit-card ml-3 w-5"></i>
                                الفواتير والاشتراك
                            </a>
                        </li>
                        <li>
                            <a href="/settings" class="sidebar-item flex items-center px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-blue-50">
                                <i class="fas fa-cog ml-3 w-5"></i>
                                إعدادات النظام
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </aside>

        <!-- المحتوى الرئيسي -->
        <main class="content-area mr-64 mt-16 p-6 h-screen overflow-y-auto">
            <!-- العنوان الرئيسي -->
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-gray-800 mb-2">مرحباً بك، أحمد محمد 👋</h1>
                <p class="text-gray-600">إليك نظرة عامة على أداء حملاتك التسويقية اليوم</p>
            </div>

            <!-- بطاقات الإحصائيات الرئيسية -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <!-- إجمالي العملاء -->
                <div class="bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition-shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-600 mb-1">إجمالي العملاء</p>
                            <p class="text-2xl font-bold text-gray-800">2,847</p>
                        </div>
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-users text-blue-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                            <i class="fas fa-arrow-up mr-1"></i>
                            +12.5%
                        </span>
                        <span class="text-xs text-gray-500 mr-2">من الشهر الماضي</span>
                    </div>
                </div>

                <!-- الحملات النشطة -->
                <div class="bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition-shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-600 mb-1">الحملات النشطة</p>
                            <p class="text-2xl font-bold text-gray-800">15</p>
                        </div>
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-bullseye text-green-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                            <i class="fas fa-plus mr-1"></i>
                            +3 جديدة
                        </span>
                        <span class="text-xs text-gray-500 mr-2">هذا الأسبوع</span>
                    </div>
                </div>

                <!-- معدل التحويل -->
                <div class="bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition-shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-600 mb-1">معدل التحويل</p>
                            <p class="text-2xl font-bold text-gray-800">18.7%</p>
                        </div>
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-chart-line text-purple-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                            <i class="fas fa-arrow-up mr-1"></i>
                            +2.3%
                        </span>
                        <span class="text-xs text-gray-500 mr-2">تحسن مستمر</span>
                    </div>
                </div>

                <!-- الإيرادات الشهرية -->
                <div class="bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition-shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-600 mb-1">الإيرادات الشهرية</p>
                            <p class="text-2xl font-bold text-gray-800">847,290 ر.س</p>
                        </div>
                        <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-dollar-sign text-orange-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                            <i class="fas fa-arrow-up mr-1"></i>
                            +24.8%
                        </span>
                        <span class="text-xs text-gray-500 mr-2">نمو ممتاز</span>
                    </div>
                </div>
            </div>

            <!-- الرسم البياني والأنشطة الحديثة -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                <!-- الرسم البياني للمبيعات -->
                <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-lg font-bold text-gray-800">أداء المبيعات الشهري</h2>
                        <div class="flex space-x-2 space-x-reverse">
                            <button class="px-3 py-1 text-xs bg-blue-100 text-blue-600 rounded-lg">30 يوم</button>
                            <button class="px-3 py-1 text-xs text-gray-500 rounded-lg">7 أيام</button>
                        </div>
                    </div>
                    
                    <!-- مخطط بياني مبسط -->
                    <div class="h-64 bg-gradient-to-t from-blue-50 to-transparent rounded-lg flex items-end justify-between px-4 py-4">
                        <div class="flex items-end space-x-2 space-x-reverse h-full">
                            <div class="bg-blue-500 rounded-t w-8" style="height: 40%"></div>
                            <div class="bg-blue-500 rounded-t w-8" style="height: 60%"></div>
                            <div class="bg-blue-500 rounded-t w-8" style="height: 80%"></div>
                            <div class="bg-blue-500 rounded-t w-8" style="height: 45%"></div>
                            <div class="bg-blue-500 rounded-t w-8" style="height: 90%"></div>
                            <div class="bg-blue-500 rounded-t w-8" style="height: 70%"></div>
                            <div class="bg-blue-500 rounded-t w-8" style="height: 100%"></div>
                        </div>
                    </div>
                    
                    <div class="flex justify-between mt-4 text-xs text-gray-500">
                        <span>الأسبوع 1</span>
                        <span>الأسبوع 2</span>
                        <span>الأسبوع 3</span>
                        <span>الأسبوع 4</span>
                    </div>
                </div>

                <!-- الأنشطة الحديثة -->
                <div class="bg-white rounded-xl shadow-sm border p-6">
                    <h2 class="text-lg font-bold text-gray-800 mb-6">الأنشطة الحديثة</h2>
                    
                    <div class="space-y-4">
                        <div class="flex items-center space-x-3 space-x-reverse">
                            <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-envelope text-green-600 text-xs"></i>
                            </div>
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-800">تم إرسال حملة بريد جديدة</p>
                                <p class="text-xs text-gray-500">منذ 5 دقائق</p>
                            </div>
                        </div>

                        <div class="flex items-center space-x-3 space-x-reverse">
                            <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-user-plus text-blue-600 text-xs"></i>
                            </div>
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-800">عميل جديد سجل في النظام</p>
                                <p class="text-xs text-gray-500">منذ 12 دقيقة</p>
                            </div>
                        </div>

                        <div class="flex items-center space-x-3 space-x-reverse">
                            <div class="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                                <i class="fab fa-whatsapp text-purple-600 text-xs"></i>
                            </div>
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-800">رسالة واتساب تم تسليمها</p>
                                <p class="text-xs text-gray-500">منذ 18 دقيقة</p>
                            </div>
                        </div>

                        <div class="flex items-center space-x-3 space-x-reverse">
                            <div class="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-chart-bar text-orange-600 text-xs"></i>
                            </div>
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-800">تقرير شهري جاهز</p>
                                <p class="text-xs text-gray-500">منذ ساعة</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- الإجراءات السريعة -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <button class="bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-xl text-right transition-colors">
                    <i class="fas fa-plus mb-2 text-xl"></i>
                    <h3 class="font-bold mb-1">حملة بريد جديدة</h3>
                    <p class="text-xs opacity-90">أنشئ حملة بريد إلكتروني</p>
                </button>

                <button class="bg-green-600 hover:bg-green-700 text-white p-4 rounded-xl text-right transition-colors">
                    <i class="fab fa-whatsapp mb-2 text-xl"></i>
                    <h3 class="font-bold mb-1">رسالة واتساب</h3>
                    <p class="text-xs opacity-90">أرسل رسالة فورية</p>
                </button>

                <button class="bg-purple-600 hover:bg-purple-700 text-white p-4 rounded-xl text-right transition-colors">
                    <i class="fas fa-users mb-2 text-xl"></i>
                    <h3 class="font-bold mb-1">إضافة عملاء</h3>
                    <p class="text-xs opacity-90">استورد قائمة عملاء جديدة</p>
                </button>

                <button class="bg-orange-600 hover:bg-orange-700 text-white p-4 rounded-xl text-right transition-colors">
                    <i class="fas fa-file-alt mb-2 text-xl"></i>
                    <h3 class="font-bold mb-1">تقرير مفصل</h3>
                    <p class="text-xs opacity-90">احصل على تقرير شامل</p>
                </button>
            </div>

            <!-- جدول الحملات الحديثة -->
            <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
                <div class="p-6 border-b">
                    <h2 class="text-lg font-bold text-gray-800">الحملات الحديثة</h2>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="text-right px-6 py-3 text-xs font-medium text-gray-500 uppercase">اسم الحملة</th>
                                <th class="text-right px-6 py-3 text-xs font-medium text-gray-500 uppercase">النوع</th>
                                <th class="text-right px-6 py-3 text-xs font-medium text-gray-500 uppercase">المرسل إليهم</th>
                                <th class="text-right px-6 py-3 text-xs font-medium text-gray-500 uppercase">معدل الفتح</th>
                                <th class="text-right px-6 py-3 text-xs font-medium text-gray-500 uppercase">الحالة</th>
                                <th class="text-right px-6 py-3 text-xs font-medium text-gray-500 uppercase">التاريخ</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 text-sm font-medium text-gray-800">عروض الجمعة البيضاء</td>
                                <td class="px-6 py-4 text-sm text-gray-600">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                                        <i class="fas fa-envelope mr-1"></i> بريد إلكتروني
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600">2,547</td>
                                <td class="px-6 py-4 text-sm text-gray-600">24.5%</td>
                                <td class="px-6 py-4">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                                        <i class="fas fa-check-circle mr-1"></i> مرسلة
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600">6 سبتمبر 2025</td>
                            </tr>
                            
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 text-sm font-medium text-gray-800">ترحيب بالعملاء الجدد</td>
                                <td class="px-6 py-4 text-sm text-gray-600">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                                        <i class="fab fa-whatsapp mr-1"></i> واتساب
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600">1,234</td>
                                <td class="px-6 py-4 text-sm text-gray-600">89.2%</td>
                                <td class="px-6 py-4">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                                        <i class="fas fa-clock mr-1"></i> جاري الإرسال
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600">5 سبتمبر 2025</td>
                            </tr>
                            
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 text-sm font-medium text-gray-800">تذكير بالعربة المهجورة</td>
                                <td class="px-6 py-4 text-sm text-gray-600">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800">
                                        <i class="fas fa-sms mr-1"></i> SMS
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600">892</td>
                                <td class="px-6 py-4 text-sm text-gray-600">67.8%</td>
                                <td class="px-6 py-4">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                                        <i class="fas fa-check-circle mr-1"></i> مرسلة
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600">4 سبتمبر 2025</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
            <div class="mb-8">
                <h2 class="text-3xl font-bold text-gray-800 mb-2">مرحباً بك في لوحة التحكم 🎉</h2>
                <p class="text-gray-600">إدارة شاملة لجميع أنشطتك التسويقية</p>
            </div>

            <!-- KPI Cards -->
            <div class="grid md:grid-cols-4 gap-6 mb-8">
                <div class="bg-white p-6 rounded-xl shadow-sm border">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-gray-600 text-sm font-medium">إجمالي العملاء</h3>
                            <p class="text-3xl font-bold text-blue-600">2,847</p>
                        </div>
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-users text-blue-600"></i>
                        </div>
                    </div>
                    <div class="text-green-600 text-sm mt-2 font-medium">
                        <i class="fas fa-arrow-up"></i> +12% من الشهر الماضي
                    </div>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-gray-600 text-sm font-medium">الحملات النشطة</h3>
                            <p class="text-3xl font-bold text-green-600">15</p>
                        </div>
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-bullseye text-green-600"></i>
                        </div>
                    </div>
                    <div class="text-green-600 text-sm mt-2 font-medium">
                        <i class="fas fa-arrow-up"></i> +3 حملات جديدة
                    </div>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-gray-600 text-sm font-medium">معدل التحويل</h3>
                            <p class="text-3xl font-bold text-purple-600">18.7%</p>
                        </div>
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-chart-line text-purple-600"></i>
                        </div>
                    </div>
                    <div class="text-green-600 text-sm mt-2 font-medium">
                        <i class="fas fa-arrow-up"></i> +2.3% تحسن
                    </div>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-gray-600 text-sm font-medium">الإيرادات الشهرية</h3>
                            <p class="text-3xl font-bold text-orange-600">847K</p>
                        </div>
                        <div class="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-dollar-sign text-orange-600"></i>
                        </div>
                    </div>
                    <div class="text-green-600 text-sm mt-2 font-medium">
                        <i class="fas fa-arrow-up"></i> +24% نمو
                    </div>
                </div>
            </div>

            <!-- Feature Cards -->
            <div class="grid md:grid-cols-3 gap-6">
                <div class="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                        <i class="fas fa-envelope text-blue-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-800 mb-2">إدارة البريد الإلكتروني</h3>
                    <p class="text-gray-600 mb-4">إنشاء وإرسال حملات بريد إلكتروني احترافية</p>
                    <button class="text-blue-600 font-medium hover:text-blue-700 transition">
                        ابدأ الآن <i class="fas fa-arrow-left mr-2"></i>
                    </button>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                        <i class="fab fa-whatsapp text-green-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-800 mb-2">واتساب بزنس</h3>
                    <p class="text-gray-600 mb-4">ربط وإدارة حساب واتساب بزنس الخاص بك</p>
                    <button class="text-green-600 font-medium hover:text-green-700 transition">
                        ربط الحساب <i class="fas fa-arrow-left mr-2"></i>
                    </button>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                        <i class="fas fa-users text-purple-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-800 mb-2">إدارة العملاء</h3>
                    <p class="text-gray-600 mb-4">نظام CRM متكامل لإدارة علاقات العملاء</p>
                    <button class="text-purple-600 font-medium hover:text-purple-700 transition">
                        عرض العملاء <i class="fas fa-arrow-left mr-2"></i>
                    </button>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition">
                    <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                        <i class="fas fa-chart-bar text-orange-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-800 mb-2">التحليلات والتقارير</h3>
                    <p class="text-gray-600 mb-4">تقارير مفصلة وإحصائيات دقيقة للأداء</p>
                    <button class="text-orange-600 font-medium hover:text-orange-700 transition">
                        عرض التقارير <i class="fas fa-arrow-left mr-2"></i>
                    </button>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition">
                    <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                        <i class="fas fa-share-alt text-red-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-800 mb-2">وسائل التواصل الاجتماعي</h3>
                    <p class="text-gray-600 mb-4">جدولة ونشر المحتوى على جميع المنصات</p>
                    <button class="text-red-600 font-medium hover:text-red-700 transition">
                        إدارة المحتوى <i class="fas fa-arrow-left mr-2"></i>
                    </button>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition">
                    <div class="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                        <i class="fas fa-robot text-indigo-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-800 mb-2">المساعد الذكي</h3>
                    <p class="text-gray-600 mb-4">أدوات الذكاء الاصطناعي لتحسين الحملات</p>
                    <button class="text-indigo-600 font-medium hover:text-indigo-700 transition">
                        استخدم الآن <i class="fas fa-arrow-left mr-2"></i>
                    </button>
                </div>
            </div>

            <!-- Success Message -->
            <div class="mt-8 bg-green-50 border border-green-200 rounded-xl p-6">
                <div class="flex items-center">
                    <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-3">
                        <i class="fas fa-check text-white"></i>
                    </div>
                    <div>
                        <h4 class="text-green-800 font-bold">✅ النظام يعمل بكامل طاقته!</h4>
                        <p class="text-green-600">جميع الميزات مفعلة وقواعد البيانات متصلة بنجاح</p>
                    </div>
                </div>
            </div>
        </main>

        <script>
            // تبديل القائمة الجانبية في الأجهزة المحمولة
            document.getElementById('sidebarToggle').addEventListener('click', function() {
                const sidebar = document.getElementById('sidebar');
                sidebar.classList.toggle('open');
            });

            // إغلاق القائمة الجانبية عند النقر خارجها في الأجهزة المحمولة
            document.addEventListener('click', function(event) {
                const sidebar = document.getElementById('sidebar');
                const toggle = document.getElementById('sidebarToggle');
                
                if (window.innerWidth <= 768 && 
                    !sidebar.contains(event.target) && 
                    !toggle.contains(event.target)) {
                    sidebar.classList.remove('open');
                }
            });

            // تسجيل الخروج
            function handleLogout() {
                if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
                    // محاكاة تسجيل الخروج
                    localStorage.clear();
                    alert('تم تسجيل الخروج بنجاح!');
                    window.location.href = '/';
                }
            }

            // تفعيل الرابط النشط في القائمة الجانبية
            document.querySelectorAll('.sidebar-item').forEach(item => {
                item.addEventListener('click', function(e) {
                    // إزالة الفئة النشطة من جميع العناصر
                    document.querySelectorAll('.sidebar-item').forEach(i => i.classList.remove('active'));
                    
                    // إضافة الفئة النشطة للعنصر المنقر
                    this.classList.add('active');
                });
            });

            // رسائل الترحيب والإشعارات
            setTimeout(() => {
                console.log('🚀 مرحباً بك في لوحة التحكم الاحترافية لـ Marketing Pro!');
                
                // إشعار ترحيبي
                const notification = document.createElement('div');
                notification.className = 'fixed top-20 left-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg z-50 opacity-0 transition-opacity duration-300';
                notification.innerHTML = '<i class="fas fa-check-circle ml-2"></i>مرحباً! جميع الأنظمة تعمل بكفاءة عالية';
                document.body.appendChild(notification);
                
                // إظهار الإشعار
                setTimeout(() => notification.classList.add('opacity-100'), 100);
                
                // إخفاء الإشعار بعد 3 ثوان
                setTimeout(() => {
                    notification.classList.remove('opacity-100');
                    setTimeout(() => document.body.removeChild(notification), 300);
                }, 3000);
            }, 1000);

            // تحديث الوقت الحقيقي للإحصائيات (محاكاة)
            setInterval(() => {
                const statsElements = document.querySelectorAll('[data-stat]');
                statsElements.forEach(element => {
                    const currentValue = parseInt(element.textContent.replace(/[^d]/g, ''));
                    const variation = Math.random() > 0.5 ? 1 : -1;
                    const newValue = currentValue + variation;
                    if (newValue > 0) {
                        element.textContent = element.textContent.replace(currentValue.toString(), newValue.toString());
                    }
                });
            }, 30000); // تحديث كل 30 ثانية
        <\/script>
    </body>
    </html>
  `));h.get("/analytics",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>التحليلات والإحصائيات - Marketing Pro</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { font-family: 'Cairo', sans-serif; }
        </style>
    </head>
    <body class="bg-gray-100">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
            <div class="flex items-center space-x-4 space-x-reverse">
                <div class="flex items-center space-x-3 space-x-reverse">
                    <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-rocket text-white text-sm"></i>
                    </div>
                    <h1 class="text-lg font-bold text-gray-800">Marketing Pro</h1>
                </div>
            </div>
            <a href="/dashboard" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition text-sm">
                <i class="fas fa-arrow-right ml-1"></i>عودة للداشبورد
            </a>
        </header>

        <!-- Content -->
        <main class="p-6">
            <div class="max-w-7xl mx-auto">
                <!-- Header -->
                <div class="mb-8">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-800 mb-2">التحليلات والإحصائيات</h1>
                            <p class="text-gray-600">تحليل شامل لأداء الحملات التسويقية وسلوك العملاء</p>
                        </div>
                        <div class="flex space-x-2 space-x-reverse">
                            <button class="px-4 py-2 bg-blue-100 text-blue-600 rounded-lg">آخر 30 يوم</button>
                            <button class="px-4 py-2 text-gray-500 rounded-lg">آخر 7 أيام</button>
                            <button class="px-4 py-2 text-gray-500 rounded-lg">اليوم</button>
                        </div>
                    </div>

                    <!-- Key Metrics -->
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">إجمالي المشاهدات</p>
                                    <p class="text-2xl font-bold text-gray-800">847,290</p>
                                    <div class="flex items-center mt-2">
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                                            <i class="fas fa-arrow-up ml-1"></i>+24.8%
                                        </span>
                                    </div>
                                </div>
                                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-eye text-blue-600 text-xl"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">معدل التحويل</p>
                                    <p class="text-2xl font-bold text-gray-800">18.7%</p>
                                    <div class="flex items-center mt-2">
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                                            <i class="fas fa-arrow-up ml-1"></i>+2.3%
                                        </span>
                                    </div>
                                </div>
                                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-chart-line text-green-600 text-xl"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">متوسط وقت الجلسة</p>
                                    <p class="text-2xl font-bold text-gray-800">4:23</p>
                                    <div class="flex items-center mt-2">
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                                            <i class="fas fa-clock ml-1"></i>+15%
                                        </span>
                                    </div>
                                </div>
                                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-clock text-purple-600 text-xl"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">معدل الارتداد</p>
                                    <p class="text-2xl font-bold text-gray-800">32.1%</p>
                                    <div class="flex items-center mt-2">
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-red-100 text-red-800">
                                            <i class="fas fa-arrow-down ml-1"></i>-8.2%
                                        </span>
                                    </div>
                                </div>
                                <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-sign-out-alt text-orange-600 text-xl"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                    <!-- Traffic Sources Chart -->
                    <div class="bg-white rounded-xl shadow-sm border p-6">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-lg font-semibold text-gray-800">مصادر الزيارات</h2>
                            <button class="text-sm text-blue-600 hover:text-blue-800">عرض التفاصيل</button>
                        </div>
                        
                        <div class="space-y-4">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <div class="w-4 h-4 bg-blue-500 rounded ml-3"></div>
                                    <span class="text-sm font-medium text-gray-700">البحث الطبيعي</span>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-bold text-gray-800">45.2%</p>
                                    <p class="text-xs text-gray-500">382,840 زيارة</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <div class="w-4 h-4 bg-green-500 rounded ml-3"></div>
                                    <span class="text-sm font-medium text-gray-700">وسائل التواصل</span>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-bold text-gray-800">28.7%</p>
                                    <p class="text-xs text-gray-500">243,190 زيارة</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <div class="w-4 h-4 bg-purple-500 rounded ml-3"></div>
                                    <span class="text-sm font-medium text-gray-700">الزيارات المباشرة</span>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-bold text-gray-800">16.8%</p>
                                    <p class="text-xs text-gray-500">142,344 زيارة</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <div class="w-4 h-4 bg-orange-500 rounded ml-3"></div>
                                    <span class="text-sm font-medium text-gray-700">الإحالات</span>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-bold text-gray-800">9.3%</p>
                                    <p class="text-xs text-gray-500">78,916 زيارة</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Device Analytics -->
                    <div class="bg-white rounded-xl shadow-sm border p-6">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-lg font-semibold text-gray-800">الأجهزة المستخدمة</h2>
                            <button class="text-sm text-blue-600 hover:text-blue-800">عرض التفاصيل</button>
                        </div>
                        
                        <div class="space-y-4">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <i class="fas fa-mobile-alt text-blue-600 ml-3"></i>
                                    <span class="text-sm font-medium text-gray-700">الهواتف المحمولة</span>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-bold text-gray-800">62.4%</p>
                                    <p class="text-xs text-gray-500">528,565 زيارة</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <i class="fas fa-desktop text-green-600 ml-3"></i>
                                    <span class="text-sm font-medium text-gray-700">أجهزة الكمبيوتر</span>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-bold text-gray-800">28.9%</p>
                                    <p class="text-xs text-gray-500">244,871 زيارة</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <i class="fas fa-tablet-alt text-purple-600 ml-3"></i>
                                    <span class="text-sm font-medium text-gray-700">الأجهزة اللوحية</span>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-bold text-gray-800">8.7%</p>
                                    <p class="text-xs text-gray-500">73,854 زيارة</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Performance Over Time -->
                <div class="bg-white rounded-xl shadow-sm border p-6 mb-8">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-lg font-semibold text-gray-800">الأداء عبر الوقت</h2>
                        <div class="flex space-x-2 space-x-reverse text-sm">
                            <span class="flex items-center"><div class="w-3 h-3 bg-blue-500 rounded ml-2"></div>الزيارات</span>
                            <span class="flex items-center"><div class="w-3 h-3 bg-green-500 rounded ml-2"></div>التحويلات</span>
                        </div>
                    </div>
                    
                    <div class="h-64 bg-gradient-to-t from-blue-50 to-transparent rounded-lg flex items-end justify-between px-4 py-4">
                        <div class="flex items-end space-x-2 space-x-reverse h-full w-full justify-between">
                            <div class="flex flex-col items-center h-full justify-end">
                                <div class="bg-green-400 rounded-t w-4 mb-1" style="height: 20%"></div>
                                <div class="bg-blue-500 rounded-t w-4" style="height: 40%"></div>
                            </div>
                            <div class="flex flex-col items-center h-full justify-end">
                                <div class="bg-green-400 rounded-t w-4 mb-1" style="height: 30%"></div>
                                <div class="bg-blue-500 rounded-t w-4" style="height: 60%"></div>
                            </div>
                            <div class="flex flex-col items-center h-full justify-end">
                                <div class="bg-green-400 rounded-t w-4 mb-1" style="height: 40%"></div>
                                <div class="bg-blue-500 rounded-t w-4" style="height: 80%"></div>
                            </div>
                            <div class="flex flex-col items-center h-full justify-end">
                                <div class="bg-green-400 rounded-t w-4 mb-1" style="height: 25%"></div>
                                <div class="bg-blue-500 rounded-t w-4" style="height: 45%"></div>
                            </div>
                            <div class="flex flex-col items-center h-full justify-end">
                                <div class="bg-green-400 rounded-t w-4 mb-1" style="height: 45%"></div>
                                <div class="bg-blue-500 rounded-t w-4" style="height: 90%"></div>
                            </div>
                            <div class="flex flex-col items-center h-full justify-end">
                                <div class="bg-green-400 rounded-t w-4 mb-1" style="height: 35%"></div>
                                <div class="bg-blue-500 rounded-t w-4" style="height: 70%"></div>
                            </div>
                            <div class="flex flex-col items-center h-full justify-end">
                                <div class="bg-green-400 rounded-t w-4 mb-1" style="height: 50%"></div>
                                <div class="bg-blue-500 rounded-t w-4" style="height: 100%"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-between mt-4 text-xs text-gray-500">
                        <span>الأسبوع 1</span>
                        <span>الأسبوع 2</span>
                        <span>الأسبوع 3</span>
                        <span>الأسبوع 4</span>
                    </div>
                </div>

                <!-- Top Performing Content -->
                <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h2 class="text-lg font-semibold text-gray-800">أفضل المحتوى أداءً</h2>
                    </div>
                    
                    <div class="divide-y divide-gray-200">
                        <div class="px-6 py-4 hover:bg-gray-50">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h3 class="font-medium text-gray-800">حملة العروض الصيفية الكبرى</h3>
                                    <p class="text-sm text-gray-500">صفحة الهبوط الرئيسية</p>
                                </div>
                                <div class="flex items-center space-x-6 space-x-reverse text-sm">
                                    <div class="text-center">
                                        <p class="font-bold text-gray-800">45,892</p>
                                        <p class="text-gray-500">زيارة</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="font-bold text-green-600">32.1%</p>
                                        <p class="text-gray-500">تحويل</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="font-bold text-blue-600">2:45</p>
                                        <p class="text-gray-500">متوسط الوقت</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="px-6 py-4 hover:bg-gray-50">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h3 class="font-medium text-gray-800">نشرة المنتجات الجديدة</h3>
                                    <p class="text-sm text-gray-500">صفحة عرض المنتجات</p>
                                </div>
                                <div class="flex items-center space-x-6 space-x-reverse text-sm">
                                    <div class="text-center">
                                        <p class="font-bold text-gray-800">28,547</p>
                                        <p class="text-gray-500">زيارة</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="font-bold text-green-600">28.7%</p>
                                        <p class="text-gray-500">تحويل</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="font-bold text-blue-600">3:12</p>
                                        <p class="text-gray-500">متوسط الوقت</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="px-6 py-4 hover:bg-gray-50">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h3 class="font-medium text-gray-800">مدونة نصائح التسويق</h3>
                                    <p class="text-sm text-gray-500">محتوى تعليمي</p>
                                </div>
                                <div class="flex items-center space-x-6 space-x-reverse text-sm">
                                    <div class="text-center">
                                        <p class="font-bold text-gray-800">19,334</p>
                                        <p class="text-gray-500">زيارة</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="font-bold text-green-600">15.3%</p>
                                        <p class="text-gray-500">تحويل</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="font-bold text-blue-600">5:23</p>
                                        <p class="text-gray-500">متوسط الوقت</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
    </html>
  `));h.get("/reports",e=>e.text("📈 صفحة التقارير المفصلة - قيد التطوير..."));h.get("/customers",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>قائمة العملاء - Marketing Pro</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { font-family: 'Cairo', sans-serif; }
        </style>
    </head>
    <body class="bg-gray-100">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
            <div class="flex items-center space-x-4 space-x-reverse">
                <div class="flex items-center space-x-3 space-x-reverse">
                    <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-rocket text-white text-sm"></i>
                    </div>
                    <h1 class="text-lg font-bold text-gray-800">Marketing Pro</h1>
                </div>
            </div>
            <a href="/dashboard" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition text-sm">
                <i class="fas fa-arrow-right ml-1"></i>عودة للداشبورد
            </a>
        </header>

        <!-- Content -->
        <main class="p-6">
            <div class="max-w-7xl mx-auto">
                <!-- Header with statistics -->
                <div class="mb-8">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-800 mb-2">إدارة العملاء</h1>
                            <p class="text-gray-600">إدارة شاملة لقاعدة عملائك وتتبع أنشطتهم</p>
                        </div>
                        <button class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl transition-colors">
                            <i class="fas fa-user-plus ml-2"></i>إضافة عميل جديد
                        </button>
                    </div>

                    <!-- Statistics Cards -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">إجمالي العملاء</p>
                                    <p class="text-2xl font-bold text-gray-800">2,847</p>
                                </div>
                                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-users text-blue-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">العملاء النشطين</p>
                                    <p class="text-2xl font-bold text-gray-800">1,923</p>
                                </div>
                                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-user-check text-green-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">عملاء جدد اليوم</p>
                                    <p class="text-2xl font-bold text-gray-800">47</p>
                                </div>
                                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-user-plus text-purple-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">متوسط القيمة</p>
                                    <p class="text-2xl font-bold text-gray-800">845 ر.س</p>
                                </div>
                                <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-chart-line text-orange-600"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filters and Search -->
                <div class="bg-white rounded-xl shadow-sm border p-6 mb-6">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                            <input type="text" placeholder="البحث في العملاء..." 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        </div>
                        <div>
                            <select class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option>جميع الحالات</option>
                                <option>نشط</option>
                                <option>غير نشط</option>
                                <option>محظور</option>
                            </select>
                        </div>
                        <div>
                            <select class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option>جميع المجموعات</option>
                                <option>VIP</option>
                                <option>عملاء عاديين</option>
                                <option>عملاء محتملين</option>
                            </select>
                        </div>
                        <div>
                            <button class="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg transition-colors">
                                <i class="fas fa-filter ml-2"></i>تصفية النتائج
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Customers Table -->
                <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h2 class="text-lg font-semibold text-gray-800">قائمة العملاء</h2>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">العميل</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">البريد الإلكتروني</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الهاتف</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">المجموعة</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الحالة</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">تاريخ التسجيل</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">أ</div>
                                            <div class="mr-4">
                                                <div class="text-sm font-medium text-gray-900">أحمد محمد</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">ahmed@example.com</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">+966501234567</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">VIP</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">نشط</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">15 يناير 2024</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <button class="text-blue-600 hover:text-blue-900 ml-2">تعديل</button>
                                        <button class="text-red-600 hover:text-red-900">حذف</button>
                                    </td>
                                </tr>
                                
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-semibold">س</div>
                                            <div class="mr-4">
                                                <div class="text-sm font-medium text-gray-900">سارة أحمد</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">sara@example.com</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">+966507654321</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">عادي</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">نشط</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">22 يناير 2024</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <button class="text-blue-600 hover:text-blue-900 ml-2">تعديل</button>
                                        <button class="text-red-600 hover:text-red-900">حذف</button>
                                    </td>
                                </tr>
                                
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white font-semibold">م</div>
                                            <div class="mr-4">
                                                <div class="text-sm font-medium text-gray-900">محمد علي</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">mohammad@example.com</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">+966503456789</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">محتمل</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">قيد المراجعة</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">28 يناير 2024</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <button class="text-blue-600 hover:text-blue-900 ml-2">تعديل</button>
                                        <button class="text-red-600 hover:text-red-900">حذف</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="px-6 py-3 bg-gray-50 border-t border-gray-200">
                        <div class="flex items-center justify-between">
                            <div class="text-sm text-gray-500">
                                عرض 1 إلى 10 من 2,847 عميل
                            </div>
                            <div class="flex items-center space-x-2 space-x-reverse">
                                <button class="px-3 py-1 text-sm bg-white border border-gray-300 rounded hover:bg-gray-50">السابق</button>
                                <button class="px-3 py-1 text-sm bg-blue-600 text-white rounded">1</button>
                                <button class="px-3 py-1 text-sm bg-white border border-gray-300 rounded hover:bg-gray-50">2</button>
                                <button class="px-3 py-1 text-sm bg-white border border-gray-300 rounded hover:bg-gray-50">3</button>
                                <button class="px-3 py-1 text-sm bg-white border border-gray-300 rounded hover:bg-gray-50">التالي</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
    </html>
  `));h.get("/segments",e=>e.text("📂 صفحة تقسيم العملاء - قيد التطوير..."));h.get("/leads",e=>e.text("🎯 صفحة العملاء المحتملين - قيد التطوير..."));h.get("/email-campaigns",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>حملات البريد الإلكتروني - Marketing Pro</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { font-family: 'Cairo', sans-serif; }
        </style>
    </head>
    <body class="bg-gray-100">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
            <div class="flex items-center space-x-4 space-x-reverse">
                <div class="flex items-center space-x-3 space-x-reverse">
                    <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-rocket text-white text-sm"></i>
                    </div>
                    <h1 class="text-lg font-bold text-gray-800">Marketing Pro</h1>
                </div>
            </div>
            <a href="/dashboard" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition text-sm">
                <i class="fas fa-arrow-right ml-1"></i>عودة للداشبورد
            </a>
        </header>

        <!-- Content -->
        <main class="p-6">
            <div class="max-w-7xl mx-auto">
                <!-- Header with statistics -->
                <div class="mb-8">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-800 mb-2">حملات البريد الإلكتروني</h1>
                            <p class="text-gray-600">إنشاء وإدارة حملات البريد الإلكتروني الفعالة</p>
                        </div>
                        <button class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl transition-colors">
                            <i class="fas fa-plus ml-2"></i>حملة جديدة
                        </button>
                    </div>

                    <!-- Statistics Cards -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">إجمالي الحملات</p>
                                    <p class="text-2xl font-bold text-gray-800">47</p>
                                </div>
                                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-envelope text-blue-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">معدل الفتح</p>
                                    <p class="text-2xl font-bold text-gray-800">24.3%</p>
                                </div>
                                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-eye text-green-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">معدل النقر</p>
                                    <p class="text-2xl font-bold text-gray-800">8.7%</p>
                                </div>
                                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-mouse-pointer text-purple-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">رسائل مرسلة</p>
                                    <p class="text-2xl font-bold text-gray-800">125,847</p>
                                </div>
                                <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-paper-plane text-orange-600"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Campaign Performance Chart -->
                <div class="bg-white rounded-xl shadow-sm border p-6 mb-6">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-lg font-semibold text-gray-800">أداء الحملات - آخر 30 يوم</h2>
                        <div class="flex space-x-2 space-x-reverse">
                            <button class="px-3 py-1 text-xs bg-blue-100 text-blue-600 rounded-lg">30 يوم</button>
                            <button class="px-3 py-1 text-xs text-gray-500 rounded-lg">7 أيام</button>
                        </div>
                    </div>
                    
                    <div class="h-48 bg-gradient-to-t from-green-50 to-transparent rounded-lg flex items-end justify-between px-4 py-4">
                        <div class="flex items-end space-x-1 space-x-reverse h-full w-full justify-between">
                            <div class="bg-green-500 rounded-t w-6" style="height: 40%"></div>
                            <div class="bg-green-500 rounded-t w-6" style="height: 60%"></div>
                            <div class="bg-green-500 rounded-t w-6" style="height: 80%"></div>
                            <div class="bg-green-500 rounded-t w-6" style="height: 45%"></div>
                            <div class="bg-green-500 rounded-t w-6" style="height: 90%"></div>
                            <div class="bg-green-500 rounded-t w-6" style="height: 70%"></div>
                            <div class="bg-green-500 rounded-t w-6" style="height: 100%"></div>
                            <div class="bg-green-500 rounded-t w-6" style="height: 85%"></div>
                        </div>
                    </div>
                </div>

                <!-- Campaigns List -->
                <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h2 class="text-lg font-semibold text-gray-800">الحملات الحالية</h2>
                    </div>
                    
                    <div class="divide-y divide-gray-200">
                        <!-- Campaign 1 -->
                        <div class="p-6 hover:bg-gray-50">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-4 space-x-reverse">
                                    <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                                        <i class="fas fa-envelope text-green-600 text-lg"></i>
                                    </div>
                                    <div>
                                        <h3 class="text-lg font-semibold text-gray-800">حملة العروض الصيفية</h3>
                                        <p class="text-sm text-gray-500">تم الإرسال إلى 2,547 عميل</p>
                                    </div>
                                </div>
                                <div class="flex items-center space-x-4 space-x-reverse">
                                    <div class="text-center">
                                        <p class="text-sm font-medium text-gray-800">معدل الفتح</p>
                                        <p class="text-lg font-bold text-green-600">32.1%</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="text-sm font-medium text-gray-800">النقرات</p>
                                        <p class="text-lg font-bold text-blue-600">12.4%</p>
                                    </div>
                                    <div class="flex space-x-2 space-x-reverse">
                                        <button class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-sm">
                                            <i class="fas fa-chart-bar ml-1"></i>التفاصيل
                                        </button>
                                        <button class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition text-sm">
                                            <i class="fas fa-copy ml-1"></i>نسخ
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Campaign 2 -->
                        <div class="p-6 hover:bg-gray-50">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-4 space-x-reverse">
                                    <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                                        <i class="fas fa-newspaper text-blue-600 text-lg"></i>
                                    </div>
                                    <div>
                                        <h3 class="text-lg font-semibold text-gray-800">نشرة إخبارية أسبوعية</h3>
                                        <p class="text-sm text-gray-500">تم الإرسال إلى 1,234 عميل</p>
                                    </div>
                                </div>
                                <div class="flex items-center space-x-4 space-x-reverse">
                                    <div class="text-center">
                                        <p class="text-sm font-medium text-gray-800">معدل الفتح</p>
                                        <p class="text-lg font-bold text-green-600">28.7%</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="text-sm font-medium text-gray-800">النقرات</p>
                                        <p class="text-lg font-bold text-blue-600">9.2%</p>
                                    </div>
                                    <div class="flex space-x-2 space-x-reverse">
                                        <button class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-sm">
                                            <i class="fas fa-chart-bar ml-1"></i>التفاصيل
                                        </button>
                                        <button class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition text-sm">
                                            <i class="fas fa-copy ml-1"></i>نسخ
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Campaign 3 -->
                        <div class="p-6 hover:bg-gray-50">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-4 space-x-reverse">
                                    <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                                        <i class="fas fa-gift text-purple-600 text-lg"></i>
                                    </div>
                                    <div>
                                        <h3 class="text-lg font-semibold text-gray-800">حملة ترحيب بالعملاء الجدد</h3>
                                        <p class="text-sm text-gray-500">مجدولة للإرسال غداً</p>
                                    </div>
                                </div>
                                <div class="flex items-center space-x-4 space-x-reverse">
                                    <span class="inline-flex px-3 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                        قيد الانتظار
                                    </span>
                                    <div class="flex space-x-2 space-x-reverse">
                                        <button class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition text-sm">
                                            <i class="fas fa-play ml-1"></i>إرسال الآن
                                        </button>
                                        <button class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition text-sm">
                                            <i class="fas fa-edit ml-1"></i>تعديل
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Templates -->
                <div class="mt-8 bg-white rounded-xl shadow-sm border p-6">
                    <h2 class="text-lg font-semibold text-gray-800 mb-4">قوالب سريعة</h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="border border-gray-200 rounded-lg p-4 hover:border-blue-500 transition-colors cursor-pointer">
                            <div class="flex items-center mb-3">
                                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center ml-3">
                                    <i class="fas fa-percentage text-blue-600"></i>
                                </div>
                                <h3 class="font-semibold text-gray-800">قالب العروض</h3>
                            </div>
                            <p class="text-sm text-gray-600">قالب للحملات الترويجية والعروض الخاصة</p>
                        </div>
                        
                        <div class="border border-gray-200 rounded-lg p-4 hover:border-blue-500 transition-colors cursor-pointer">
                            <div class="flex items-center mb-3">
                                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center ml-3">
                                    <i class="fas fa-newspaper text-green-600"></i>
                                </div>
                                <h3 class="font-semibold text-gray-800">النشرة الإخبارية</h3>
                            </div>
                            <p class="text-sm text-gray-600">قالب للنشرات الإخبارية الدورية</p>
                        </div>
                        
                        <div class="border border-gray-200 rounded-lg p-4 hover:border-blue-500 transition-colors cursor-pointer">
                            <div class="flex items-center mb-3">
                                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center ml-3">
                                    <i class="fas fa-heart text-purple-600"></i>
                                </div>
                                <h3 class="font-semibold text-gray-800">رسالة ترحيب</h3>
                            </div>
                            <p class="text-sm text-gray-600">قالب للترحيب بالعملاء الجدد</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
    </html>
  `));h.get("/whatsapp",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>واتساب بزنس - Marketing Pro</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { font-family: 'Cairo', sans-serif; }
        </style>
    </head>
    <body class="bg-gray-100">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
            <div class="flex items-center space-x-4 space-x-reverse">
                <div class="flex items-center space-x-3 space-x-reverse">
                    <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-rocket text-white text-sm"></i>
                    </div>
                    <h1 class="text-lg font-bold text-gray-800">Marketing Pro</h1>
                </div>
            </div>
            <a href="/dashboard" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition text-sm">
                <i class="fas fa-arrow-right ml-1"></i>عودة للداشبورد
            </a>
        </header>

        <!-- Content -->
        <main class="p-6">
            <div class="max-w-7xl mx-auto">
                <!-- Header -->
                <div class="mb-8">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-800 mb-2">واتساب بزنس</h1>
                            <p class="text-gray-600">إدارة الرسائل والحملات عبر واتساب بزنس</p>
                        </div>
                        <button class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl transition-colors">
                            <i class="fas fa-plus ml-2"></i>رسالة جديدة
                        </button>
                    </div>

                    <!-- Connection Status -->
                    <div class="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center ml-3">
                                    <i class="fab fa-whatsapp text-green-600 text-lg"></i>
                                </div>
                                <div>
                                    <h3 class="font-semibold text-green-800">واتساب متصل بنجاح</h3>
                                    <p class="text-sm text-green-600">آخر تحديث: منذ دقيقتين</p>
                                </div>
                            </div>
                            <div class="flex items-center">
                                <span class="w-3 h-3 bg-green-500 rounded-full animate-pulse ml-2"></span>
                                <span class="text-green-700 font-medium">متصل</span>
                            </div>
                        </div>
                    </div>

                    <!-- Statistics Cards -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">رسائل اليوم</p>
                                    <p class="text-2xl font-bold text-gray-800">2,847</p>
                                </div>
                                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-paper-plane text-blue-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">تم التسليم</p>
                                    <p class="text-2xl font-bold text-gray-800">2,701</p>
                                </div>
                                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-check-double text-green-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">تم القراءة</p>
                                    <p class="text-2xl font-bold text-gray-800">1,987</p>
                                </div>
                                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-eye text-purple-600"></i>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">معدل الاستجابة</p>
                                    <p class="text-2xl font-bold text-gray-800">73.5%</p>
                                </div>
                                <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-reply text-orange-600"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Recent Messages -->
                    <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border">
                        <div class="px-6 py-4 border-b border-gray-200">
                            <h2 class="text-lg font-semibold text-gray-800">الرسائل الحديثة</h2>
                        </div>
                        
                        <div class="divide-y divide-gray-200">
                            <!-- Message 1 -->
                            <div class="p-4 hover:bg-gray-50">
                                <div class="flex items-start space-x-3 space-x-reverse">
                                    <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                                        أ
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center justify-between">
                                            <p class="text-sm font-medium text-gray-900">أحمد محمد</p>
                                            <p class="text-xs text-gray-500">منذ 5 دقائق</p>
                                        </div>
                                        <p class="text-sm text-gray-600 mt-1">مرحباً، أريد معرفة المزيد عن خدماتكم</p>
                                        <div class="flex items-center mt-2">
                                            <span class="inline-flex px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                                                <i class="fas fa-check-double ml-1 text-xs"></i>تم التسليم
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Message 2 -->
                            <div class="p-4 hover:bg-gray-50">
                                <div class="flex items-start space-x-3 space-x-reverse">
                                    <div class="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                                        س
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center justify-between">
                                            <p class="text-sm font-medium text-gray-900">سارة أحمد</p>
                                            <p class="text-xs text-gray-500">منذ 12 دقيقة</p>
                                        </div>
                                        <p class="text-sm text-gray-600 mt-1">شكراً لكم على المتابعة السريعة</p>
                                        <div class="flex items-center mt-2">
                                            <span class="inline-flex px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                                                <i class="fas fa-eye ml-1 text-xs"></i>تم القراءة
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Message 3 -->
                            <div class="p-4 hover:bg-gray-50">
                                <div class="flex items-start space-x-3 space-x-reverse">
                                    <div class="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                                        م
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center justify-between">
                                            <p class="text-sm font-medium text-gray-900">محمد علي</p>
                                            <p class="text-xs text-gray-500">منذ 18 دقيقة</p>
                                        </div>
                                        <p class="text-sm text-gray-600 mt-1">متى سيكون موعد التسليم؟</p>
                                        <div class="flex items-center mt-2">
                                            <span class="inline-flex px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                                                <i class="fas fa-clock ml-1 text-xs"></i>في الانتظار
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions and Templates -->
                    <div class="space-y-6">
                        <!-- Quick Send -->
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-4">إرسال سريع</h3>
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
                                    <input type="text" placeholder="+966501234567" 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">الرسالة</label>
                                    <textarea rows="3" placeholder="اكتب رسالتك هنا..." 
                                              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"></textarea>
                                </div>
                                <button class="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-colors">
                                    <i class="fab fa-whatsapp ml-2"></i>إرسال الآن
                                </button>
                            </div>
                        </div>

                        <!-- Message Templates -->
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-4">القوالب الجاهزة</h3>
                            <div class="space-y-3">
                                <div class="border border-gray-200 rounded-lg p-3 hover:border-green-500 transition-colors cursor-pointer">
                                    <div class="flex items-center mb-2">
                                        <i class="fas fa-handshake text-green-600 ml-2"></i>
                                        <span class="font-medium text-gray-800">رسالة ترحيب</span>
                                    </div>
                                    <p class="text-xs text-gray-600">مرحباً بكم في خدماتنا...</p>
                                </div>
                                
                                <div class="border border-gray-200 rounded-lg p-3 hover:border-green-500 transition-colors cursor-pointer">
                                    <div class="flex items-center mb-2">
                                        <i class="fas fa-percentage text-blue-600 ml-2"></i>
                                        <span class="font-medium text-gray-800">عرض خاص</span>
                                    </div>
                                    <p class="text-xs text-gray-600">عرض خاص لفترة محدودة...</p>
                                </div>
                                
                                <div class="border border-gray-200 rounded-lg p-3 hover:border-green-500 transition-colors cursor-pointer">
                                    <div class="flex items-center mb-2">
                                        <i class="fas fa-shipping-fast text-orange-600 ml-2"></i>
                                        <span class="font-medium text-gray-800">تحديث الطلب</span>
                                    </div>
                                    <p class="text-xs text-gray-600">تم شحن طلبكم بنجاح...</p>
                                </div>
                            </div>
                        </div>

                        <!-- Broadcast -->
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-4">الإذاعة الجماعية</h3>
                            <div class="space-y-4">
                                <div class="text-center p-4 bg-gray-50 rounded-lg">
                                    <i class="fas fa-bullhorn text-gray-400 text-2xl mb-2"></i>
                                    <p class="text-sm text-gray-600">إرسال رسالة لجميع العملاء</p>
                                </div>
                                <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-colors">
                                    <i class="fas fa-broadcast-tower ml-2"></i>إنشاء حملة إذاعة
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
    </html>
  `));h.get("/social-media",e=>e.text("📱 صفحة وسائل التواصل الاجتماعي - قيد التطوير..."));h.get("/sms-campaigns",e=>e.text("💬 صفحة حملات الرسائل النصية - قيد التطوير..."));h.get("/automation",e=>e.text("🤖 صفحة الأتمتة الذكية - قيد التطوير..."));h.get("/templates",e=>e.text("📄 صفحة قوالب الرسائل - قيد التطوير..."));h.get("/integrations",e=>e.text("🔌 صفحة التكامل مع التطبيقات - قيد التطوير..."));h.get("/profile",e=>e.text("👤 صفحة الملف الشخصي - قيد التطوير..."));h.get("/team",e=>e.text("👥 صفحة إدارة الفريق - قيد التطوير..."));h.get("/billing",e=>e.text("💳 صفحة الفواتير والاشتراك - قيد التطوير..."));h.get("/marketing-strategy",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>استراتيجية التسويق بالذكاء الاصطناعي - Marketing Pro</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"><\/script>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { font-family: 'Cairo', sans-serif; }
            .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
            .ai-loading {
                background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
                background-size: 400% 400%;
                animation: gradient 2s ease infinite;
            }
            @keyframes gradient {
                0% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
                100% { background-position: 0% 50%; }
            }
            .strategy-card {
                transition: all 0.3s ease;
                backdrop-filter: blur(10px);
            }
            .strategy-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            }
        </style>
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6 sticky top-0 z-40">
            <div class="flex items-center space-x-4 space-x-reverse">
                <div class="flex items-center space-x-3 space-x-reverse">
                    <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-rocket text-white text-sm"></i>
                    </div>
                    <h1 class="text-lg font-bold text-gray-800">Marketing Pro</h1>
                </div>
            </div>
            <a href="/dashboard" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition text-sm">
                <i class="fas fa-arrow-right ml-1"></i>عودة للداشبورد
            </a>
        </header>

        <div class="min-h-screen">
            <!-- Hero Section -->
            <div class="gradient-bg text-white py-12">
                <div class="max-w-7xl mx-auto px-6 text-center">
                    <div class="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur-lg rounded-full mb-6">
                        <i class="fas fa-brain text-3xl text-white"></i>
                    </div>
                    <h1 class="text-4xl md:text-5xl font-bold mb-4">استراتيجية التسويق بالذكاء الاصطناعي</h1>
                    <p class="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">احصل على استراتيجية تسويقية شاملة ومخصصة لعملك باستخدام أحدث تقنيات الذكاء الاصطناعي</p>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mt-12">
                        <div class="bg-white/10 backdrop-blur-lg rounded-xl p-6 text-center">
                            <i class="fas fa-magic text-2xl mb-3"></i>
                            <h3 class="font-semibold mb-2">ذكاء اصطناعي متقدم</h3>
                            <p class="text-sm text-blue-100">تحليل شامل لعملك والسوق</p>
                        </div>
                        <div class="bg-white/10 backdrop-blur-lg rounded-xl p-6 text-center">
                            <i class="fas fa-download text-2xl mb-3"></i>
                            <h3 class="font-semibold mb-2">قابل للتصدير</h3>
                            <p class="text-sm text-blue-100">تصدير PDF أو Word مع هويتك</p>
                        </div>
                        <div class="bg-white/10 backdrop-blur-lg rounded-xl p-6 text-center">
                            <i class="fas fa-rocket text-2xl mb-3"></i>
                            <h3 class="font-semibold mb-2">جاهز للتنفيذ</h3>
                            <p class="text-sm text-blue-100">خطة عملية قابلة للتطبيق</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="max-w-7xl mx-auto px-6 py-12">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    <!-- Form Section -->
                    <div class="bg-white rounded-2xl shadow-xl p-8">
                        <div class="text-center mb-8">
                            <div class="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                                <i class="fas fa-clipboard-list text-blue-600 text-2xl"></i>
                            </div>
                            <h2 class="text-2xl font-bold text-gray-800 mb-2">معلومات عن عملك</h2>
                            <p class="text-gray-600">أدخل التفاصيل التالية للحصول على استراتيجية مخصصة</p>
                        </div>

                        <form id="strategyForm" class="space-y-6">
                            <!-- اسم البزنس -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-building text-blue-600 ml-2"></i>
                                    اسم البزنس / الشركة *
                                </label>
                                <input type="text" id="businessName" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                       placeholder="مثال: متجر الإلكترونيات الذكية">
                            </div>

                            <!-- نبذة عن البزنس -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-info-circle text-blue-600 ml-2"></i>
                                    نبذة عن البزنس *
                                </label>
                                <textarea id="businessDescription" required rows="4"
                                          class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                                          placeholder="اشرح طبيعة عملك، المنتجات أو الخدمات التي تقدمها، وما يميزك عن المنافسين..."></textarea>
                            </div>

                            <!-- الفئة المستهدفة -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-users text-blue-600 ml-2"></i>
                                    الفئة المستهدفة *
                                </label>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                                    <select id="targetAge" class="px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                                        <option value="">الفئة العمرية</option>
                                        <option value="18-25">18-25 سنة</option>
                                        <option value="26-35">26-35 سنة</option>
                                        <option value="36-45">36-45 سنة</option>
                                        <option value="46-55">46-55 سنة</option>
                                        <option value="55+">أكثر من 55 سنة</option>
                                        <option value="all">جميع الأعمار</option>
                                    </select>
                                    <select id="targetGender" class="px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                                        <option value="">الجنس</option>
                                        <option value="male">ذكور</option>
                                        <option value="female">إناث</option>
                                        <option value="both">كلاهما</option>
                                    </select>
                                </div>
                                <textarea id="targetDetails" rows="3"
                                          class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                                          placeholder="تفاصيل إضافية عن الجمهور المستهدف (الاهتمامات، المستوى التعليمي، المهن، السلوكيات الشرائية...)"></textarea>
                            </div>

                            <!-- مكان البزنس -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-map-marker-alt text-blue-600 ml-2"></i>
                                    مكان البزنس *
                                </label>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <select id="businessCountry" required class="px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                                        <option value="">اختر البلد</option>
                                        <option value="saudi">السعودية</option>
                                        <option value="uae">الإمارات</option>
                                        <option value="kuwait">الكويت</option>
                                        <option value="qatar">قطر</option>
                                        <option value="bahrain">البحرين</option>
                                        <option value="oman">عُمان</option>
                                        <option value="jordan">الأردن</option>
                                        <option value="egypt">مصر</option>
                                        <option value="lebanon">لبنان</option>
                                        <option value="morocco">المغرب</option>
                                        <option value="other">أخرى</option>
                                    </select>
                                    <input type="text" id="businessCity"
                                           class="px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                           placeholder="المدينة">
                                </div>
                            </div>

                            <!-- نوع البزنس -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-store text-blue-600 ml-2"></i>
                                    نوع البزنس
                                </label>
                                <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="businessType" value="online" class="ml-2">
                                        <span class="text-sm">متجر إلكتروني</span>
                                    </label>
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="businessType" value="physical" class="ml-2">
                                        <span class="text-sm">متجر فعلي</span>
                                    </label>
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="businessType" value="service" class="ml-2">
                                        <span class="text-sm">خدمات</span>
                                    </label>
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="businessType" value="restaurant" class="ml-2">
                                        <span class="text-sm">مطعم</span>
                                    </label>
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="businessType" value="clinic" class="ml-2">
                                        <span class="text-sm">عيادة طبية</span>
                                    </label>
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="businessType" value="education" class="ml-2">
                                        <span class="text-sm">تعليم</span>
                                    </label>
                                </div>
                            </div>

                            <!-- المنافسين -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-chess text-blue-600 ml-2"></i>
                                    المنافسين الرئيسيين
                                </label>
                                <textarea id="competitors" rows="3"
                                          class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                                          placeholder="اذكر أسماء أهم 3-5 منافسين في مجالك، وما يميز كل منهم..."></textarea>
                            </div>

                            <!-- الميزانية التسويقية -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-dollar-sign text-blue-600 ml-2"></i>
                                    الميزانية التسويقية الشهرية
                                </label>
                                <select id="marketingBudget" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                                    <option value="">اختر الميزانية</option>
                                    <option value="0-1000">أقل من 1,000 ريال</option>
                                    <option value="1000-5000">1,000 - 5,000 ريال</option>
                                    <option value="5000-10000">5,000 - 10,000 ريال</option>
                                    <option value="10000-25000">10,000 - 25,000 ريال</option>
                                    <option value="25000+">أكثر من 25,000 ريال</option>
                                </select>
                            </div>

                            <!-- أهداف التسويق -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-bullseye text-blue-600 ml-2"></i>
                                    الأهداف التسويقية
                                </label>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="goals" value="brand-awareness" class="ml-2">
                                        <span class="text-sm">زيادة الوعي بالعلامة التجارية</span>
                                    </label>
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="goals" value="sales" class="ml-2">
                                        <span class="text-sm">زيادة المبيعات</span>
                                    </label>
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="goals" value="leads" class="ml-2">
                                        <span class="text-sm">جذب عملاء محتملين</span>
                                    </label>
                                    <label class="flex items-center p-3 border border-gray-300 rounded-xl cursor-pointer hover:bg-blue-50 transition">
                                        <input type="checkbox" name="goals" value="customer-retention" class="ml-2">
                                        <span class="text-sm">الاحتفاظ بالعملاء الحاليين</span>
                                    </label>
                                </div>
                            </div>

                            <!-- زر إنشاء الاستراتيجية -->
                            <button type="submit" id="generateBtn" class="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl font-bold text-lg hover:from-blue-700 hover:to-purple-700 transition-all transform hover:scale-105 shadow-lg">
                                <i class="fas fa-magic ml-2"></i>
                                <span id="btnText">إنشاء استراتيجية التسويق بالذكاء الاصطناعي</span>
                                <div id="loadingSpinner" class="hidden inline-block w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                            </button>
                        </form>
                    </div>

                    <!-- Preview/Results Section -->
                    <div class="space-y-8">
                        <!-- Preview Card -->
                        <div id="previewCard" class="bg-white rounded-2xl shadow-xl p-8 hidden">
                            <div class="text-center mb-6">
                                <div class="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                                    <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                                </div>
                                <h3 class="text-xl font-bold text-gray-800 mb-2">تم إنشاء الاستراتيجية بنجاح!</h3>
                                <p class="text-gray-600">استراتيجية تسويقية شاملة ومخصصة لعملك</p>
                            </div>
                            
                            <div class="space-y-4 mb-6">
                                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                                    <span class="font-medium text-gray-700">اسم البزنس</span>
                                    <span id="previewBusinessName" class="text-blue-600 font-semibold"></span>
                                </div>
                                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                                    <span class="font-medium text-gray-700">الفئة المستهدفة</span>
                                    <span id="previewTarget" class="text-blue-600 font-semibold"></span>
                                </div>
                                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                                    <span class="font-medium text-gray-700">المكان</span>
                                    <span id="previewLocation" class="text-blue-600 font-semibold"></span>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <button onclick="exportToPDF()" class="bg-red-600 hover:bg-red-700 text-white py-3 px-6 rounded-xl font-bold transition-colors">
                                    <i class="fas fa-file-pdf ml-2"></i>تصدير PDF
                                </button>
                                <button onclick="exportToWord()" class="bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-xl font-bold transition-colors">
                                    <i class="fas fa-file-word ml-2"></i>تصدير Word
                                </button>
                            </div>
                        </div>

                        <!-- Strategy Result -->
                        <div id="strategyResult" class="bg-white rounded-2xl shadow-xl p-8 hidden">
                            <div class="mb-6 text-center">
                                <h3 class="text-2xl font-bold text-gray-800 mb-2">استراتيجيتك التسويقية</h3>
                                <p class="text-gray-600">خطة تسويقية شاملة مدعومة بالذكاء الاصطناعي</p>
                            </div>
                            
                            <div id="strategyContent" class="space-y-6">
                                <!-- سيتم ملء المحتوى هنا بواسطة JavaScript -->
                            </div>
                        </div>

                        <!-- Features Info -->
                        <div class="bg-gradient-to-r from-purple-500 to-blue-600 rounded-2xl p-8 text-white">
                            <h3 class="text-xl font-bold mb-4">ماذا تتضمن استراتيجيتك؟</h3>
                            <div class="space-y-3">
                                <div class="flex items-center">
                                    <i class="fas fa-check-circle text-green-300 ml-3"></i>
                                    <span>تحليل شامل للسوق والمنافسين</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-check-circle text-green-300 ml-3"></i>
                                    <span>تحديد الجمهور المستهدف بدقة</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-check-circle text-green-300 ml-3"></i>
                                    <span>استراتيجية المحتوى والرسائل التسويقية</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-check-circle text-green-300 ml-3"></i>
                                    <span>خطة تسويق رقمي متكاملة</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-check-circle text-green-300 ml-3"></i>
                                    <span>توزيع الميزانية على القنوات المناسبة</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-check-circle text-green-300 ml-3"></i>
                                    <span>مؤشرات الأداء الرئيسية (KPIs)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Loading Modal -->
        <div id="loadingModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-2xl p-8 max-w-md w-full mx-4 text-center">
                <div class="ai-loading w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <i class="fas fa-brain text-white text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">الذكاء الاصطناعي يعمل...</h3>
                <p class="text-gray-600 mb-4">جاري تحليل معلومات عملك وإنشاء استراتيجية مخصصة</p>
                <div class="w-full bg-gray-200 rounded-full h-2">
                    <div id="progressBar" class="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full transition-all duration-500" style="width: 0%"></div>
                </div>
                <p id="progressText" class="text-sm text-gray-500 mt-2">بدء التحليل...</p>
            </div>
        </div>

        <script>
            let generatedStrategy = null;
            let currentBusinessName = '';

            document.getElementById('strategyForm').addEventListener('submit', function(e) {
                e.preventDefault();
                generateStrategy();
            });

            async function generateStrategy() {
                const formData = new FormData(document.getElementById('strategyForm'));
                const data = {
                    businessName: document.getElementById('businessName').value,
                    businessDescription: document.getElementById('businessDescription').value,
                    targetAge: document.getElementById('targetAge').value,
                    targetGender: document.getElementById('targetGender').value,
                    targetDetails: document.getElementById('targetDetails').value,
                    businessCountry: document.getElementById('businessCountry').value,
                    businessCity: document.getElementById('businessCity').value,
                    businessType: Array.from(document.querySelectorAll('input[name="businessType"]:checked')).map(cb => cb.value),
                    competitors: document.getElementById('competitors').value,
                    marketingBudget: document.getElementById('marketingBudget').value,
                    goals: Array.from(document.querySelectorAll('input[name="goals"]:checked')).map(cb => cb.value)
                };

                if (!data.businessName || !data.businessDescription) {
                    alert('يرجى ملء الحقول المطلوبة (اسم البزنس والنبذة)');
                    return;
                }

                currentBusinessName = data.businessName;
                showLoadingModal();
                
                // محاكاة إنشاء الاستراتيجية بالذكاء الاصطناعي
                await simulateAIGeneration(data);
            }

            async function simulateAIGeneration(data) {
                const progressSteps = [
                    { percent: 20, text: 'تحليل معلومات العمل...' },
                    { percent: 40, text: 'دراسة السوق والمنافسين...' },
                    { percent: 60, text: 'تحديد الجمهور المستهدف...' },
                    { percent: 80, text: 'إنشاء الاستراتيجية التسويقية...' },
                    { percent: 100, text: 'اكتمال إنشاء الاستراتيجية!' }
                ];

                for (const step of progressSteps) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    updateProgress(step.percent, step.text);
                }

                await new Promise(resolve => setTimeout(resolve, 500));
                hideLoadingModal();
                displayStrategy(data);
            }

            function updateProgress(percent, text) {
                document.getElementById('progressBar').style.width = percent + '%';
                document.getElementById('progressText').textContent = text;
            }

            function showLoadingModal() {
                document.getElementById('loadingModal').classList.remove('hidden');
                updateProgress(0, 'بدء التحليل...');
            }

            function hideLoadingModal() {
                document.getElementById('loadingModal').classList.add('hidden');
            }

            function displayStrategy(data) {
                // عرض معاينة سريعة
                document.getElementById('previewBusinessName').textContent = data.businessName;
                document.getElementById('previewTarget').textContent = 
                    (data.targetAge || 'غير محدد') + ' - ' + (data.targetGender || 'غير محدد');
                document.getElementById('previewLocation').textContent = 
                    (data.businessCity || '') + (data.businessCity && data.businessCountry ? ', ' : '') + 
                    (document.querySelector('#businessCountry option:checked')?.textContent || '');
                
                document.getElementById('previewCard').classList.remove('hidden');

                // إنشاء الاستراتيجية الكاملة
                generatedStrategy = generateFullStrategy(data);
                displayFullStrategy(generatedStrategy);
                
                document.getElementById('strategyResult').classList.remove('hidden');
                document.getElementById('strategyResult').scrollIntoView({ behavior: 'smooth' });
            }

            function generateFullStrategy(data) {
                const strategy = {
                    businessName: data.businessName,
                    executiveSummary: \`تم تطوير هذه الاستراتيجية التسويقية خصيصاً لـ "\${data.businessName}" باستخدام تقنيات الذكاء الاصطناعي المتقدمة. تهدف هذه الاستراتيجية إلى تحقيق نمو مستدام وزيادة الوعي بالعلامة التجارية في السوق المستهدف.\`,
                    
                    targetAudience: {
                        primary: \`الفئة العمرية: \${data.targetAge || 'متنوعة'} | الجنس: \${data.targetGender || 'مختلط'}\`,
                        details: data.targetDetails || 'جمهور عام مهتم بالمنتجات/الخدمات المقدمة',
                        personas: [
                            'الشخصية الأولى: العميل المهتم بالجودة والقيمة',
                            'الشخصية الثانية: العميل الباحث عن الحلول السريعة',
                            'الشخصية الثالثة: العميل المهتم بالعلامات التجارية الموثوقة'
                        ]
                    },

                    marketAnalysis: {
                        competitors: data.competitors || 'منافسون محليون وإقليميون في نفس القطاع',
                        opportunities: [
                            'نمو السوق الرقمي في المنطقة',
                            'زيادة الاعتماد على التسوق الإلكتروني',
                            'الحاجة لحلول مبتكرة في القطاع',
                            'فرص التوسع في أسواق جديدة'
                        ],
                        threats: [
                            'المنافسة الشديدة في السوق',
                            'تغيير سلوكيات المستهلكين',
                            'التحديات الاقتصادية',
                            'التطورات التكنولوجية السريعة'
                        ]
                    },

                    marketingChannels: [
                        {
                            channel: 'وسائل التواصل الاجتماعي',
                            platforms: ['Instagram', 'Twitter', 'LinkedIn', 'TikTok'],
                            budget: '40%',
                            activities: [
                                'إنشاء محتوى تفاعلي يومي',
                                'حملات إعلانية مستهدفة',
                                'التفاعل مع المتابعين',
                                'شراكات مع المؤثرين'
                            ]
                        },
                        {
                            channel: 'التسويق الرقمي',
                            platforms: ['Google Ads', 'Facebook Ads', 'YouTube'],
                            budget: '35%',
                            activities: [
                                'حملات البحث المدفوعة',
                                'إعلانات العرض والفيديو',
                                'إعادة الاستهداف',
                                'تحسين محركات البحث'
                            ]
                        },
                        {
                            channel: 'التسويق بالمحتوى',
                            platforms: ['الموقع الإلكتروني', 'المدونة', 'البودكاست'],
                            budget: '15%',
                            activities: [
                                'إنشاء مقالات تعليمية',
                                'فيديوهات توضيحية',
                                'دراسات حالة',
                                'النشرات الإخبارية'
                            ]
                        },
                        {
                            channel: 'التسويق التقليدي',
                            platforms: ['الراديو', 'الصحف', 'اللوحات الإعلانية'],
                            budget: '10%',
                            activities: [
                                'إعلانات راديو في أوقات الذروة',
                                'إعلانات مطبوعة مستهدفة',
                                'رعاية الفعاليات المحلية'
                            ]
                        }
                    ],

                    contentStrategy: {
                        themes: [
                            'التعريف بالمنتجات والخدمات',
                            'قصص نجاح العملاء',
                            'النصائح والإرشادات المهنية',
                            'أحدث الاتجاهات في القطاع',
                            'خلف الكواليس والفريق'
                        ],
                        frequency: {
                            'Instagram': 'يومياً (1-2 منشور)',
                            'Twitter': '3-4 مرات يومياً',
                            'LinkedIn': '3-4 مرات أسبوعياً',
                            'المدونة': 'مرتين أسبوعياً',
                            'البريد الإلكتروني': 'أسبوعياً'
                        }
                    },

                    timeline: [
                        {
                            phase: 'المرحلة الأولى (الشهر 1-2)',
                            activities: [
                                'إطلاق الحملات على وسائل التواصل',
                                'تحسين الموقع الإلكتروني',
                                'بدء حملات Google Ads',
                                'إنشاء المحتوى الأساسي'
                            ]
                        },
                        {
                            phase: 'المرحلة الثانية (الشهر 3-4)',
                            activities: [
                                'توسيع الحملات الإعلانية',
                                'شراكات مع المؤثرين',
                                'تطوير برنامج الولاء',
                                'قياس وتحليل النتائج'
                            ]
                        },
                        {
                            phase: 'المرحلة الثالثة (الشهر 5-6)',
                            activities: [
                                'تحسين الاستراتيجية حسب النتائج',
                                'إطلاق حملات موسمية',
                                'توسيع نطاق الوصول',
                                'تطوير منتجات/خدمات جديدة'
                            ]
                        }
                    ],

                    kpis: [
                        { metric: 'الوعي بالعلامة التجارية', target: 'زيادة 50% خلال 6 أشهر', measurement: 'استطلاعات الرأي ومقاييس وسائل التواصل' },
                        { metric: 'حركة المرور للموقع', target: 'زيادة 75% خلال 3 أشهر', measurement: 'Google Analytics' },
                        { metric: 'معدل التحويل', target: 'تحسين بنسبة 25%', measurement: 'تتبع المبيعات والعملاء المحتملين' },
                        { metric: 'التفاعل على وسائل التواصل', target: 'زيادة 100% في المتابعين والتفاعل', measurement: 'منصات التواصل الاجتماعي' },
                        { metric: 'العائد على الاستثمار', target: 'ROI بنسبة 300% كحد أدنى', measurement: 'تحليل المبيعات والتكاليف' }
                    ],

                    budget: data.marketingBudget ? \`ميزانية شهرية: \${data.marketingBudget} ريال\` : 'حسب الميزانية المتاحة',
                    
                    recommendations: [
                        'البدء بحملات وسائل التواصل الاجتماعي لأنها الأكثر فعالية من ناحية التكلفة',
                        'الاستثمار في المحتوى عالي الجودة والمفيد للجمهور المستهدف',
                        'بناء قاعدة بيانات عملاء قوية لتحسين التسويق المستهدف',
                        'مراقبة المنافسين وتحليل استراتيجياتهم بانتظام',
                        'الاستثمار في تدريب الفريق على أحدث اتجاهات التسويق الرقمي',
                        'تطوير نظام قياس فعال لتتبع أداء جميع الحملات التسويقية'
                    ]
                };

                return strategy;
            }

            function displayFullStrategy(strategy) {
                const strategyContent = document.getElementById('strategyContent');
                
                strategyContent.innerHTML = \`
                    <div class="space-y-8">
                        <!-- الملخص التنفيذي -->
                        <div class="strategy-card bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-blue-800 mb-3 flex items-center">
                                <i class="fas fa-clipboard-list ml-2"></i>
                                الملخص التنفيذي
                            </h4>
                            <p class="text-gray-700 leading-relaxed">\${strategy.executiveSummary}</p>
                        </div>

                        <!-- تحليل الجمهور المستهدف -->
                        <div class="strategy-card bg-white border border-gray-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-users ml-2 text-green-600"></i>
                                الجمهور المستهدف
                            </h4>
                            <div class="space-y-4">
                                <div>
                                    <h5 class="font-semibold text-gray-700 mb-2">الفئة الأساسية:</h5>
                                    <p class="text-gray-600">\${strategy.targetAudience.primary}</p>
                                </div>
                                <div>
                                    <h5 class="font-semibold text-gray-700 mb-2">التفاصيل:</h5>
                                    <p class="text-gray-600">\${strategy.targetAudience.details}</p>
                                </div>
                                <div>
                                    <h5 class="font-semibold text-gray-700 mb-2">شخصيات العملاء:</h5>
                                    <ul class="list-disc list-inside text-gray-600 space-y-1">
                                        \${strategy.targetAudience.personas.map(persona => \`<li>\${persona}</li>\`).join('')}
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- تحليل السوق -->
                        <div class="strategy-card bg-white border border-gray-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-chart-bar ml-2 text-purple-600"></i>
                                تحليل السوق
                            </h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <h5 class="font-semibold text-gray-700 mb-3 text-green-600">الفرص المتاحة:</h5>
                                    <ul class="list-disc list-inside text-gray-600 space-y-1">
                                        \${strategy.marketAnalysis.opportunities.map(opp => \`<li>\${opp}</li>\`).join('')}
                                    </ul>
                                </div>
                                <div>
                                    <h5 class="font-semibold text-gray-700 mb-3 text-red-600">التحديات:</h5>
                                    <ul class="list-disc list-inside text-gray-600 space-y-1">
                                        \${strategy.marketAnalysis.threats.map(threat => \`<li>\${threat}</li>\`).join('')}
                                    </ul>
                                </div>
                            </div>
                            <div class="mt-4">
                                <h5 class="font-semibold text-gray-700 mb-2">المنافسين:</h5>
                                <p class="text-gray-600">\${strategy.marketAnalysis.competitors}</p>
                            </div>
                        </div>

                        <!-- القنوات التسويقية -->
                        <div class="strategy-card bg-white border border-gray-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-bullhorn ml-2 text-orange-600"></i>
                                القنوات التسويقية المقترحة
                            </h4>
                            <div class="space-y-6">
                                \${strategy.marketingChannels.map(channel => \`
                                    <div class="border border-gray-100 rounded-lg p-4">
                                        <div class="flex justify-between items-center mb-3">
                                            <h5 class="font-semibold text-gray-800">\${channel.channel}</h5>
                                            <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">\${channel.budget} من الميزانية</span>
                                        </div>
                                        <p class="text-sm text-gray-600 mb-3"><strong>المنصات:</strong> \${channel.platforms.join(', ')}</p>
                                        <div>
                                            <h6 class="font-medium text-gray-700 mb-2">الأنشطة المقترحة:</h6>
                                            <ul class="list-disc list-inside text-gray-600 text-sm space-y-1">
                                                \${channel.activities.map(activity => \`<li>\${activity}</li>\`).join('')}
                                            </ul>
                                        </div>
                                    </div>
                                \`).join('')}
                            </div>
                        </div>

                        <!-- استراتيجية المحتوى -->
                        <div class="strategy-card bg-white border border-gray-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-pen-fancy ml-2 text-indigo-600"></i>
                                استراتيجية المحتوى
                            </h4>
                            <div class="space-y-4">
                                <div>
                                    <h5 class="font-semibold text-gray-700 mb-2">محاور المحتوى:</h5>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                                        \${strategy.contentStrategy.themes.map(theme => \`
                                            <div class="bg-indigo-50 text-indigo-800 px-3 py-2 rounded-lg text-sm">\${theme}</div>
                                        \`).join('')}
                                    </div>
                                </div>
                                <div>
                                    <h5 class="font-semibold text-gray-700 mb-2">تكرار النشر المقترح:</h5>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        \${Object.entries(strategy.contentStrategy.frequency).map(([platform, freq]) => \`
                                            <div class="flex justify-between items-center p-2 bg-gray-50 rounded">
                                                <span class="text-gray-700">\${platform}</span>
                                                <span class="text-gray-600 text-sm">\${freq}</span>
                                            </div>
                                        \`).join('')}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- الجدول الزمني -->
                        <div class="strategy-card bg-white border border-gray-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-calendar-alt ml-2 text-teal-600"></i>
                                الجدول الزمني للتنفيذ
                            </h4>
                            <div class="space-y-4">
                                \${strategy.timeline.map((phase, index) => \`
                                    <div class="border border-gray-100 rounded-lg p-4">
                                        <h5 class="font-semibold text-gray-800 mb-3">\${phase.phase}</h5>
                                        <ul class="list-disc list-inside text-gray-600 space-y-1">
                                            \${phase.activities.map(activity => \`<li>\${activity}</li>\`).join('')}
                                        </ul>
                                    </div>
                                \`).join('')}
                            </div>
                        </div>

                        <!-- مؤشرات الأداء -->
                        <div class="strategy-card bg-white border border-gray-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-chart-line ml-2 text-green-600"></i>
                                مؤشرات الأداء الرئيسية (KPIs)
                            </h4>
                            <div class="overflow-x-auto">
                                <table class="w-full text-sm">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="text-right p-3 font-semibold text-gray-700">المؤشر</th>
                                            <th class="text-right p-3 font-semibold text-gray-700">الهدف</th>
                                            <th class="text-right p-3 font-semibold text-gray-700">طريقة القياس</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        \${strategy.kpis.map(kpi => \`
                                            <tr class="border-t border-gray-100">
                                                <td class="p-3 text-gray-800">\${kpi.metric}</td>
                                                <td class="p-3 text-gray-600">\${kpi.target}</td>
                                                <td class="p-3 text-gray-600">\${kpi.measurement}</td>
                                            </tr>
                                        \`).join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- الميزانية -->
                        <div class="strategy-card bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-green-800 mb-3 flex items-center">
                                <i class="fas fa-dollar-sign ml-2"></i>
                                الميزانية المقترحة
                            </h4>
                            <p class="text-gray-700">\${strategy.budget}</p>
                        </div>

                        <!-- التوصيات -->
                        <div class="strategy-card bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200 rounded-xl p-6">
                            <h4 class="text-lg font-bold text-amber-800 mb-4 flex items-center">
                                <i class="fas fa-lightbulb ml-2"></i>
                                التوصيات الاستراتيجية
                            </h4>
                            <ul class="list-disc list-inside text-gray-700 space-y-2">
                                \${strategy.recommendations.map(rec => \`<li>\${rec}</li>\`).join('')}
                            </ul>
                        </div>
                    </div>
                \`;
            }

            function exportToPDF() {
                if (!generatedStrategy) return;

                try {
                    const { jsPDF } = window.jspdf;
                    const doc = new jsPDF();
                    
                    // إعداد الخط العربي (محاكاة - في التطبيق الحقيقي نحتاج خط عربي)
                    doc.setFont("helvetica");
                    doc.setFontSize(16);
                    
                    let yPosition = 20;
                    const margin = 20;
                    const lineHeight = 10;
                    
                    // عنوان الاستراتيجية
                    doc.text(\`Marketing Strategy for \${currentBusinessName}\`, margin, yPosition, { align: 'left' });
                    yPosition += lineHeight * 2;
                    
                    // إضافة شعار وهوية الشركة
                    doc.setFontSize(12);
                    doc.text('Generated by Marketing Pro AI', margin, yPosition);
                    yPosition += lineHeight;
                    doc.text(\`Date: \${new Date().toLocaleDateString('ar-SA')}\`, margin, yPosition);
                    yPosition += lineHeight * 2;
                    
                    // إضافة محتوى الاستراتيجية (مبسط للمثال)
                    doc.setFontSize(14);
                    doc.text('Executive Summary:', margin, yPosition);
                    yPosition += lineHeight;
                    
                    doc.setFontSize(10);
                    const summaryLines = doc.splitTextToSize(generatedStrategy.executiveSummary, 170);
                    summaryLines.forEach(line => {
                        if (yPosition > 270) {
                            doc.addPage();
                            yPosition = 20;
                        }
                        doc.text(line, margin, yPosition);
                        yPosition += lineHeight;
                    });
                    
                    // حفظ الملف
                    doc.save(\`\${currentBusinessName}_Marketing_Strategy.pdf\`);
                    
                    alert('تم تصدير الاستراتيجية بصيغة PDF بنجاح!');
                } catch (error) {
                    console.error('Error generating PDF:', error);
                    alert('حدث خطأ في تصدير PDF. يرجى المحاولة مرة أخرى.');
                }
            }

            function exportToWord() {
                if (!generatedStrategy) return;
                
                try {
                    // إنشاء محتوى HTML للتصدير
                    const htmlContent = \`
                        <!DOCTYPE html>
                        <html dir="rtl" lang="ar">
                        <head>
                            <meta charset="UTF-8">
                            <title>استراتيجية التسويق - \${currentBusinessName}</title>
                            <style>
                                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 40px; line-height: 1.6; }
                                .header { text-align: center; border-bottom: 2px solid #2563eb; padding-bottom: 20px; margin-bottom: 30px; }
                                .company-name { color: #2563eb; font-size: 24px; font-weight: bold; margin-bottom: 10px; }
                                .generated-by { color: #6b7280; font-size: 14px; }
                                .section { margin: 30px 0; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; }
                                .section-title { color: #1f2937; font-size: 18px; font-weight: bold; margin-bottom: 15px; border-bottom: 1px solid #e5e7eb; padding-bottom: 5px; }
                                .subsection { margin: 15px 0; }
                                .subsection-title { color: #374151; font-weight: bold; margin-bottom: 8px; }
                                ul { padding-right: 20px; }
                                li { margin: 5px 0; }
                                .kpi-table { width: 100%; border-collapse: collapse; margin: 15px 0; }
                                .kpi-table th, .kpi-table td { border: 1px solid #d1d5db; padding: 10px; text-align: right; }
                                .kpi-table th { background-color: #f3f4f6; font-weight: bold; }
                            </style>
                        </head>
                        <body>
                            <div class="header">
                                <div class="company-name">استراتيجية التسويق - \${currentBusinessName}</div>
                                <div class="generated-by">
                                    تم إنشاؤها بواسطة Marketing Pro AI | \${new Date().toLocaleDateString('ar-SA')}
                                </div>
                            </div>

                            <div class="section">
                                <div class="section-title">الملخص التنفيذي</div>
                                <p>\${generatedStrategy.executiveSummary}</p>
                            </div>

                            <div class="section">
                                <div class="section-title">الجمهور المستهدف</div>
                                <div class="subsection">
                                    <div class="subsection-title">الفئة الأساسية:</div>
                                    <p>\${generatedStrategy.targetAudience.primary}</p>
                                </div>
                                <div class="subsection">
                                    <div class="subsection-title">التفاصيل:</div>
                                    <p>\${generatedStrategy.targetAudience.details}</p>
                                </div>
                                <div class="subsection">
                                    <div class="subsection-title">شخصيات العملاء:</div>
                                    <ul>
                                        \${generatedStrategy.targetAudience.personas.map(persona => \`<li>\${persona}</li>\`).join('')}
                                    </ul>
                                </div>
                            </div>

                            <div class="section">
                                <div class="section-title">القنوات التسويقية المقترحة</div>
                                \${generatedStrategy.marketingChannels.map(channel => \`
                                    <div class="subsection">
                                        <div class="subsection-title">\${channel.channel} (\${channel.budget} من الميزانية)</div>
                                        <p><strong>المنصات:</strong> \${channel.platforms.join(', ')}</p>
                                        <p><strong>الأنشطة المقترحة:</strong></p>
                                        <ul>
                                            \${channel.activities.map(activity => \`<li>\${activity}</li>\`).join('')}
                                        </ul>
                                    </div>
                                \`).join('')}
                            </div>

                            <div class="section">
                                <div class="section-title">مؤشرات الأداء الرئيسية</div>
                                <table class="kpi-table">
                                    <thead>
                                        <tr>
                                            <th>المؤشر</th>
                                            <th>الهدف</th>
                                            <th>طريقة القياس</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        \${generatedStrategy.kpis.map(kpi => \`
                                            <tr>
                                                <td>\${kpi.metric}</td>
                                                <td>\${kpi.target}</td>
                                                <td>\${kpi.measurement}</td>
                                            </tr>
                                        \`).join('')}
                                    </tbody>
                                </table>
                            </div>

                            <div class="section">
                                <div class="section-title">التوصيات الاستراتيجية</div>
                                <ul>
                                    \${generatedStrategy.recommendations.map(rec => \`<li>\${rec}</li>\`).join('')}
                                </ul>
                            </div>
                        </body>
                        </html>
                    \`;

                    // إنشاء Blob وتحميل الملف
                    const blob = new Blob([htmlContent], { type: 'application/msword' });
                    const url = window.URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = \`\${currentBusinessName}_Marketing_Strategy.doc\`;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                    
                    alert('تم تصدير الاستراتيجية بصيغة Word بنجاح!');
                } catch (error) {
                    console.error('Error generating Word document:', error);
                    alert('حدث خطأ في تصدير Word. يرجى المحاولة مرة أخرى.');
                }
            }
        <\/script>
    </body>
    </html>
  `));h.get("/settings",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>إعدادات النظام - Marketing Pro</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
            body { font-family: 'Cairo', sans-serif; }
        </style>
    </head>
    <body class="bg-gray-100">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
            <div class="flex items-center space-x-4 space-x-reverse">
                <div class="flex items-center space-x-3 space-x-reverse">
                    <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-rocket text-white text-sm"></i>
                    </div>
                    <h1 class="text-lg font-bold text-gray-800">Marketing Pro</h1>
                </div>
            </div>
            <a href="/dashboard" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition text-sm">
                <i class="fas fa-arrow-right ml-1"></i>عودة للداشبورد
            </a>
        </header>

        <!-- Content -->
        <main class="p-6">
            <div class="max-w-4xl mx-auto">
                <!-- Header -->
                <div class="mb-8">
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">إعدادات النظام</h1>
                    <p class="text-gray-600">إدارة إعدادات الحساب والنظام العامة</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
                    <!-- Settings Navigation -->
                    <div class="bg-white rounded-xl shadow-sm border p-4">
                        <nav class="space-y-2">
                            <button class="w-full text-right px-4 py-3 rounded-lg bg-blue-50 text-blue-600 font-medium transition-colors">
                                <i class="fas fa-user ml-2"></i>الملف الشخصي
                            </button>
                            <button class="w-full text-right px-4 py-3 rounded-lg text-gray-600 hover:bg-gray-50 font-medium transition-colors">
                                <i class="fas fa-bell ml-2"></i>الإشعارات
                            </button>
                            <button class="w-full text-right px-4 py-3 rounded-lg text-gray-600 hover:bg-gray-50 font-medium transition-colors">
                                <i class="fas fa-shield-alt ml-2"></i>الأمان
                            </button>
                            <button class="w-full text-right px-4 py-3 rounded-lg text-gray-600 hover:bg-gray-50 font-medium transition-colors">
                                <i class="fas fa-envelope ml-2"></i>البريد الإلكتروني
                            </button>
                            <button class="w-full text-right px-4 py-3 rounded-lg text-gray-600 hover:bg-gray-50 font-medium transition-colors">
                                <i class="fab fa-whatsapp ml-2"></i>واتساب
                            </button>
                            <button class="w-full text-right px-4 py-3 rounded-lg text-gray-600 hover:bg-gray-50 font-medium transition-colors">
                                <i class="fas fa-cog ml-2"></i>عام
                            </button>
                        </nav>
                    </div>

                    <!-- Settings Content -->
                    <div class="lg:col-span-3 space-y-6">
                        <!-- Profile Settings -->
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <h2 class="text-lg font-semibold text-gray-800 mb-6">معلومات الملف الشخصي</h2>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">الاسم الأول</label>
                                    <input type="text" value="أحمد" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">الاسم الأخير</label>
                                    <input type="text" value="محمد" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">البريد الإلكتروني</label>
                                    <input type="email" value="admin@marketingpro.com" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
                                    <input type="tel" value="+966501234567" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                                
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">المنصب</label>
                                    <input type="text" value="مدير التسويق" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                                
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">نبذة مختصرة</label>
                                    <textarea rows="3" placeholder="اكتب نبذة مختصرة عنك..." 
                                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none">مدير تسويق متخصص في الحملات الرقمية وإدارة العلاقات مع العملاء</textarea>
                                </div>
                            </div>
                            
                            <div class="mt-6 flex justify-end">
                                <button class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors">
                                    <i class="fas fa-save ml-2"></i>حفظ التغييرات
                                </button>
                            </div>
                        </div>

                        <!-- Notification Settings -->
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <h2 class="text-lg font-semibold text-gray-800 mb-6">إعدادات الإشعارات</h2>
                            
                            <div class="space-y-4">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <h3 class="font-medium text-gray-800">إشعارات البريد الإلكتروني</h3>
                                        <p class="text-sm text-gray-500">استلام إشعارات عن الحملات والأنشطة الجديدة</p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" checked class="sr-only peer">
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                    </label>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div>
                                        <h3 class="font-medium text-gray-800">إشعارات واتساب</h3>
                                        <p class="text-sm text-gray-500">استلام إشعارات عبر واتساب للرسائل المهمة</p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" checked class="sr-only peer">
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                    </label>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div>
                                        <h3 class="font-medium text-gray-800">تقارير الأداء اليومية</h3>
                                        <p class="text-sm text-gray-500">استلام ملخص يومي عن أداء الحملات</p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" class="sr-only peer">
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                    </label>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div>
                                        <h3 class="font-medium text-gray-800">إشعارات العملاء الجدد</h3>
                                        <p class="text-sm text-gray-500">التنبيه عند تسجيل عملاء جدد</p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" checked class="sr-only peer">
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- Integration Settings -->
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <h2 class="text-lg font-semibold text-gray-800 mb-6">إعدادات التكامل</h2>
                            
                            <div class="space-y-4">
                                <div class="border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center ml-3">
                                                <i class="fab fa-whatsapp text-green-600"></i>
                                            </div>
                                            <div>
                                                <h3 class="font-medium text-gray-800">واتساب بزنس</h3>
                                                <p class="text-sm text-gray-500">متصل - آخر مزامنة منذ 5 دقائق</p>
                                            </div>
                                        </div>
                                        <div class="flex items-center space-x-2 space-x-reverse">
                                            <span class="w-3 h-3 bg-green-500 rounded-full"></span>
                                            <span class="text-sm font-medium text-green-600">متصل</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center ml-3">
                                                <i class="fas fa-envelope text-blue-600"></i>
                                            </div>
                                            <div>
                                                <h3 class="font-medium text-gray-800">خدمة البريد الإلكتروني</h3>
                                                <p class="text-sm text-gray-500">متصل - SMTP مُكوّن</p>
                                            </div>
                                        </div>
                                        <div class="flex items-center space-x-2 space-x-reverse">
                                            <span class="w-3 h-3 bg-green-500 rounded-full"></span>
                                            <span class="text-sm font-medium text-green-600">متصل</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center ml-3">
                                                <i class="fab fa-google text-gray-400"></i>
                                            </div>
                                            <div>
                                                <h3 class="font-medium text-gray-800">Google Analytics</h3>
                                                <p class="text-sm text-gray-500">غير متصل - يتطلب الإعداد</p>
                                            </div>
                                        </div>
                                        <button class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-sm">
                                            ربط الآن
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Security Settings -->
                        <div class="bg-white rounded-xl shadow-sm border p-6">
                            <h2 class="text-lg font-semibold text-gray-800 mb-6">إعدادات الأمان</h2>
                            
                            <div class="space-y-6">
                                <div>
                                    <h3 class="font-medium text-gray-800 mb-4">تغيير كلمة المرور</h3>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">كلمة المرور الحالية</label>
                                            <input type="password" 
                                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">كلمة المرور الجديدة</label>
                                            <input type="password" 
                                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                        </div>
                                    </div>
                                    <button class="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors text-sm">
                                        <i class="fas fa-key ml-2"></i>تحديث كلمة المرور
                                    </button>
                                </div>
                                
                                <div class="border-t pt-6">
                                    <h3 class="font-medium text-gray-800 mb-4">المصادقة الثنائية</h3>
                                    <div class="flex items-center justify-between">
                                        <div>
                                            <p class="text-sm text-gray-600">تعزيز أمان حسابك بالمصادقة الثنائية</p>
                                        </div>
                                        <button class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition text-sm">
                                            تفعيل الآن
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
    </html>
  `));h.get("/demo",e=>e.text("🎬 صفحة العرض التوضيحي - قيد التطوير..."));h.get("/api/test",e=>e.json({success:!0,message:"Marketing Pro API يعمل بنجاح! 🚀",timestamp:new Date().toISOString(),status:"جميع الأنظمة تعمل بكفاءة عالية"}));h.get("/health",e=>e.json({status:"healthy",message:"Marketing Pro is running perfectly! 🚀",timestamp:new Date().toISOString()}));const Ue=new mt,Qt=Object.assign({"/src/index.tsx":h});let bt=!1;for(const[,e]of Object.entries(Qt))e&&(Ue.route("/",e),Ue.notFound(e.notFoundHandler),bt=!0);if(!bt)throw new Error("Can't import modules from ['/src/index.tsx','/app/server.ts']");export{Ue as default};
